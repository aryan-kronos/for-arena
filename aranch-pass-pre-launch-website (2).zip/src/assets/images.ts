/**
 * Images are imported through Vite so the production bundle never depends on a
 * separate asset request path. Source files live in /public/images/ and can be
 * replaced in place — the filenames below are the contract.
 */
import aranchPassTicket from "../../public/images/aranch-pass-ticket.jpg";
import aranchPassFiftyBox from "../../public/images/aranch-pass-fifty-box.jpg";
import heroPassActivation from "../../public/images/hero-pass-activation.jpg";
import activationCloseup from "../../public/images/activation-closeup.jpg";
import customerReturnScan from "../../public/images/customer-return-scan.jpg";
import realMaterialTest from "../../public/images/real-material-test.jpg";
import realFirstBatch from "../../public/images/real-first-batch.jpg";
import boardServiceLoop from "../../public/images/board-service-loop.jpg";
import boardAttachedAsset from "../../public/images/board-attached-asset.jpg";

export {
  aranchPassTicket,
  aranchPassFiftyBox,
  heroPassActivation,
  activationCloseup,
  customerReturnScan,
  realMaterialTest,
  realFirstBatch,
  boardServiceLoop,
  boardAttachedAsset,
};
