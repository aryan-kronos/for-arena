import { useCallback, useState } from "react";
import {
  Card,
  Chip,
  Container,
  ImageCard,
  Note,
  SealRing,
  SectionHead,
  TraceLine,
} from "@/components/ui";
import { alts, assets, gridLegend, ritualSteps, type GridState } from "@/data";
import { useReveal, useScrollProgress } from "@/hooks/useReveal";
import { cn } from "@/utils/cn";

/* ------------------------------------------------------------------ */
/* The physical pass                                                    */
/* ------------------------------------------------------------------ */

const callouts = [
  { code: "01", label: "Unique QR", body: "One code per pass. Never reprinted, never shared between assets." },
  { code: "02", label: "Readable asset code", body: "AP-7K3M9 — short enough to say out loud on a phone call." },
  { code: "03", label: "Numbered issue", body: "01/50 keeps a physical box auditable against the software." },
  { code: "04", label: "Durable identifier", body: "Planned for durable service use; material tests are still pending." },
  { code: "05", label: "Safe public scan", body: "Opens service information a stranger can safely be shown." },
];

export function PhysicalPass() {
  const ref = useReveal<HTMLElement>();
  return (
    <section id="pass" ref={ref} className="relative overflow-hidden bg-cream py-20 sm:py-28">
      <Container>
        <div className="reveal">
          <SectionHead
            eyebrow="Chapter 04 · The object"
            title="A service record with somewhere to live."
            lede="The pass is the whole idea made physical: an identity that stays on the machine long after the technician has left."
            aside={<Chip tone="saffron">Approved design direction</Chip>}
          />
        </div>

        <div className="mt-14 grid gap-8 lg:grid-cols-[1.12fr_0.88fr] lg:gap-12">
          <div className="reveal relative">
            <div
              aria-hidden="true"
              className="absolute inset-0 m-auto aspect-square w-[74%] rounded-full bg-saffron/25"
            />
            <figure className="pin pin-hover relative overflow-hidden bg-white p-4 sm:p-7">
              <div className="pin-media fit-contain aspect-[43/25] rounded-[20px] bg-white">
                <img
                  src={assets.passImage}
                  alt={alts.passImage}
                  loading="lazy"
                  decoding="async"
                  draggable={false}
                />
              </div>
              <figcaption className="mono mt-4 flex flex-wrap items-center justify-between gap-2 px-1 text-[10px] tracking-[0.12em] text-muted uppercase">
                <span>aranch-pass-ticket · concept visual</span>
                <span className="text-violet">No provider name printed</span>
              </figcaption>
            </figure>
          </div>

          <ul className="reveal grid content-center gap-3">
            {callouts.map((c) => (
              <li key={c.code}>
                <Card hover pad="p-5" className="flex gap-4">
                  <span className="mono mt-0.5 h-7 shrink-0 rounded-full bg-violet/10 px-2.5 py-1.5 text-[11px] leading-none text-violet">
                    {c.code}
                  </span>
                  <div>
                    <h3 className="text-[15px] font-bold text-deepviolet">{c.label}</h3>
                    <p className="mt-1 text-[14px] leading-relaxed text-ink/70">{c.body}</p>
                  </div>
                </Card>
              </li>
            ))}
          </ul>
        </div>

        <Note className="mt-8">
          Not described as tamper-proof, waterproof or weatherproof. Those words need a material
          test behind them, and that test has not happened yet.
        </Note>
      </Container>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Activation ritual                                                    */
/* ------------------------------------------------------------------ */

function StepDiagram({ index }: { index: number }) {
  return (
    <svg viewBox="0 0 160 110" className="h-24 w-full" aria-hidden="true">
      <g stroke="#4D1688" strokeWidth="1.7" fill="none" strokeLinecap="round">
        {index === 0 && (
          <>
            <rect x="24" y="48" width="90" height="50" rx="12" />
            <path d="M24 60 h90" opacity="0.35" />
            <rect x="62" y="14" width="72" height="42" rx="12" fill="#FBF6E9" transform="rotate(-9 98 35)" />
            <circle cx="110" cy="32" r="11" stroke="#F4AD08" />
          </>
        )}
        {index === 1 && (
          <>
            <rect x="54" y="10" width="54" height="90" rx="14" />
            <rect x="66" y="30" width="30" height="30" rx="8" stroke="#F4AD08" />
            <path d="M66 76 h30 M66 86 h18" opacity="0.45" />
          </>
        )}
        {index === 2 && (
          <>
            <rect x="26" y="18" width="108" height="74" rx="14" />
            <path d="M40 40 h48 M40 55 h68 M40 70 h36" opacity="0.5" />
            <circle cx="116" cy="70" r="12" stroke="#F4AD08" />
            <path d="M110 70 l4 5 l9 -11" stroke="#F4AD08" />
          </>
        )}
        {index === 3 && (
          <>
            <rect x="36" y="12" width="88" height="88" rx="16" />
            <path d="M36 32 h88" opacity="0.35" />
            <rect x="60" y="54" width="44" height="26" rx="10" fill="#F4AD08" stroke="#4D1688" />
            <circle cx="82" cy="67" r="6" stroke="#2E0759" />
          </>
        )}
      </g>
    </svg>
  );
}

export function ActivationRitual() {
  const ref = useReveal<HTMLElement>();
  const [active, setActive] = useState(0);
  return (
    <section id="ritual" ref={ref} className="bg-paper py-20 sm:py-28">
      <Container>
        <div className="reveal">
          <SectionHead
            eyebrow="Chapter 05 · The activation ritual"
            title="Under a minute to give the service a memory."
            aside={
              <Note className="lg:text-right">
                Workflow target for the pilot; final timing will be tested with technicians.
              </Note>
            }
          />
        </div>

        <TraceLine className="mt-10 h-8 w-full" />

        <ol className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {ritualSteps.map((s, i) => (
            <li key={s.n}>
              <Card
                hover
                tone={active === i ? "cream" : "light"}
                className="reveal h-full cursor-default transition-colors duration-300"
              >
                <div
                  onMouseEnter={() => setActive(i)}
                  onFocus={() => setActive(i)}
                  tabIndex={0}
                  className="outline-none"
                >
                  <div className="flex items-center justify-between">
                    <Chip>{s.n}</Chip>
                    <span
                      aria-hidden="true"
                      className={cn(
                        "h-2.5 w-2.5 rounded-full transition-colors",
                        active === i ? "bg-saffron" : "bg-violet/20",
                      )}
                    />
                  </div>
                  <StepDiagram index={i} />
                  <h3 className="font-display mt-4 text-[1.35rem] text-deepviolet">{s.title}</h3>
                  <p className="mt-2 text-[14px] leading-relaxed text-ink/70">{s.body}</p>
                </div>
              </Card>
            </li>
          ))}
        </ol>
      </Container>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* The 50-pass box                                                      */
/* ------------------------------------------------------------------ */

const boxCodes = ["AP-7K3M9", "AP-2R8QD", "AP-9V4XL", "AP-5B1TC", "AP-3H6NZ", "AP-8M2WK"];

export function PassBox() {
  const ref = useReveal<HTMLElement>();
  return (
    <section ref={ref} className="relative overflow-hidden bg-deepviolet py-20 text-ivory sm:py-28">
      <SealRing
        className="pointer-events-none absolute -bottom-40 -left-32 w-[460px] opacity-20"
        tone="ivory"
        text="FIFTY PASSES · ONE BOX · "
      />
      <Container className="relative">
        <div className="grid gap-12 lg:grid-cols-[0.95fr_1.05fr] lg:items-center lg:gap-14">
          <div className="reveal">
            <SectionHead
              tone="dark"
              eyebrow="Chapter 06 · The box"
              title="Fifty completed jobs, ready to stay connected."
              lede="Each box contains a numbered set of unique service passes. Every QR and asset code is issued individually; the provider activates them as work is completed."
            />

            <div className="mt-9 flex items-center gap-5">
              <span className="font-display text-[clamp(2.4rem,7vw,3.4rem)] text-saffron">01</span>
              <span className="h-12 w-px bg-ivory/25" />
              <span className="mono text-[13px] tracking-[0.2em] text-ivory/60">/ 50 ISSUED</span>
            </div>

            <ul className="mt-7 flex flex-wrap gap-2">
              {boxCodes.map((c) => (
                <li key={c}>
                  <Chip tone="dark">{c}</Chip>
                </li>
              ))}
              <li>
                <span className="mono px-2 py-1.5 text-[11px] text-ivory/40">+ 44 more</span>
              </li>
            </ul>

            <div className="mt-9 rounded-[22px] bg-plum/50 p-5 ring-1 ring-ivory/12">
              <Note tone="dark">
                Packaging concept shown. Final material, dimensions and print production are still
                being tested.
              </Note>
            </div>
          </div>

          <div className="reveal grid gap-4">
            <figure className="pin pin-hover overflow-hidden bg-white">
              <div className="pin-media aspect-[4/5] sm:aspect-[5/4]">
                <img
                  src={assets.boxImage}
                  alt={alts.boxImage}
                  loading="lazy"
                  decoding="async"
                  draggable={false}
                />
              </div>
            </figure>
            <div className="grid grid-cols-2 gap-4">
              <ImageCard img="firstBatch" ratio="aspect-[4/3]" />
              <ImageCard img="loopStill" ratio="aspect-[4/3]" />
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Activation grid                                                      */
/* ------------------------------------------------------------------ */

const stateStyles: Record<GridState, string> = {
  issued: "border-line bg-transparent text-muted",
  activated: "border-violet bg-violet text-paper",
  due: "border-saffron bg-saffron text-plum",
  rebooked: "border-deepviolet bg-white text-deepviolet",
};

function stateFor(i: number, p: number): GridState {
  const reach = p * 64 - 6;
  if (i > reach) return "issued";
  if (i > reach - 9) return "activated";
  if (i % 7 === 3) return "due";
  if (i % 5 === 0) return "rebooked";
  return "activated";
}

const narrative = [
  { code: "01/50", label: "issued" },
  { code: "12/50", label: "activated" },
  { code: "31/50", label: "due soon" },
  { code: "50/50", label: "ready for the next box" },
];

export function ActivationGrid() {
  const [p, setP] = useState(0);
  const onProgress = useCallback((v: number) => setP(v), []);
  const ref = useScrollProgress<HTMLElement>(onProgress);
  const cells = Array.from({ length: 50 }, (_, i) => i + 1);

  return (
    <section ref={ref} className="bg-paper py-20 sm:py-28">
      <Container>
        <div className="grid gap-10 lg:grid-cols-[0.88fr_1.12fr] lg:gap-14">
          <div>
            <SectionHead
              eyebrow="Chapter 07 · Activation grid"
              title="Physical passes, tracked as software states."
              lede="Every pass in a box has a state. As jobs are completed the box empties and the dashboard fills — the same fifty identifiers, seen from two sides."
            />

            <ul className="mt-8 grid gap-3">
              {gridLegend.map((l) => (
                <li key={l.state} className="flex items-start gap-3">
                  <span
                    aria-hidden="true"
                    className={cn("mt-1 h-3.5 w-3.5 shrink-0 rounded-[5px] border", stateStyles[l.state])}
                  />
                  <span className="text-[14px] text-ink/80">
                    <span className="font-semibold text-deepviolet">{l.label}</span>
                    <span className="text-muted"> — {l.hint}</span>
                  </span>
                </li>
              ))}
            </ul>

            <Note className="mt-7">
              Illustrative demo states. These are not real customer records and no live data appears
              anywhere on this page.
            </Note>
          </div>

          <div>
            <Card pad="p-5 sm:p-7">
              <div className="mono flex items-center justify-between text-[10px] tracking-[0.14em] text-violet uppercase">
                <span>Box A · 50 passes</span>
                <Chip tone="saffron">Demo</Chip>
              </div>
              <div className="mt-4 grid grid-cols-5 gap-2 sm:grid-cols-10 sm:gap-2.5">
                {cells.map((n) => {
                  const st = stateFor(n, p);
                  return (
                    <div
                      key={n}
                      title={`${String(n).padStart(2, "0")}/50 · ${st}`}
                      className={cn(
                        "mono flex aspect-[5/3] items-center justify-center rounded-[9px] border text-[9px] transition-colors duration-500",
                        stateStyles[st],
                      )}
                    >
                      {String(n).padStart(2, "0")}
                    </div>
                  );
                })}
              </div>
            </Card>

            <ul className="mt-4 grid gap-2 sm:grid-cols-2">
              {narrative.map((n) => (
                <li
                  key={n.code}
                  className="mono flex items-center justify-between rounded-full bg-cream px-4 py-3 text-[11px] tracking-[0.08em] text-ink/70"
                >
                  <span className="text-violet">{n.code}</span>
                  <span className="uppercase">{n.label}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </Container>
    </section>
  );
}
