import { InteractivePass } from "@/components/InteractivePass";
import { Button, Card, Chip, Container, ImageCard, Note, SealRing, SectionHead } from "@/components/ui";
import { offers, principles, site, transparency } from "@/data";
import { useReveal } from "@/hooks/useReveal";
import { cn } from "@/utils/cn";

/* Offer architecture --------------------------------------------------- */

export function OfferArchitecture() {
  const ref = useReveal<HTMLElement>();
  return (
    <section ref={ref} className="bg-cream py-20 sm:py-28">
      <Container>
        <div className="reveal">
          <SectionHead
            eyebrow="Chapter 13 · Offer architecture"
            title="Three ways this may be bought."
            aside={<Chip>{site.pricingLabel}</Chip>}
          />
        </div>

        <div className="mt-12 grid gap-5 lg:grid-cols-3">
          {offers.map((o) => (
            <Card
              key={o.code}
              hover
              tone={o.featured ? "violet" : "light"}
              className="reveal flex h-full flex-col"
            >
              <div className="flex items-center justify-between gap-2">
                <Chip tone={o.featured ? "dark" : "light"}>{o.code}</Chip>
                {o.featured && <Chip tone="saffron">Pilot focus</Chip>}
              </div>
              <h3
                className={cn(
                  "font-display mt-6 text-[1.6rem]",
                  o.featured ? "text-ivory" : "text-deepviolet",
                )}
              >
                {o.title}
              </h3>
              <p className={cn("mt-2 text-[14px]", o.featured ? "text-ivory/70" : "text-muted")}>
                {o.lede}
              </p>
              <ul className="mt-6 flex-1 space-y-3">
                {o.items.map((it) => (
                  <li key={it} className="flex gap-3 text-[14px] leading-relaxed">
                    <span
                      aria-hidden="true"
                      className="mt-[7px] h-1.5 w-1.5 shrink-0 rounded-full bg-saffron"
                    />
                    <span className={o.featured ? "text-ivory/85" : "text-ink/80"}>{it}</span>
                  </li>
                ))}
              </ul>
              <div
                className={cn(
                  "mono mt-7 border-t pt-4 text-[10px] tracking-[0.12em] uppercase",
                  o.featured ? "border-ivory/20 text-ivory/55" : "border-line text-muted",
                )}
              >
                {site.pricingVisible ? o.price : "Pricing not published yet"}
              </div>
            </Card>
          ))}
        </div>

        <Note className="mt-6">
          Pricing is deliberately not shown. When it exists it will be set around active assets,
          branches and automation — not by counting technicians, which would punish teams for
          onboarding the people who actually use the product.
        </Note>
      </Container>
    </section>
  );
}

/* Mission and principles ----------------------------------------------- */

export function MissionPrinciples() {
  const ref = useReveal<HTMLElement>();
  return (
    <section id="mission" ref={ref} className="relative overflow-hidden bg-plum py-20 text-ivory sm:py-28">
      <Container className="relative">
        <div className="grid gap-12 lg:grid-cols-[1.12fr_0.88fr] lg:items-center">
          <div className="reveal">
            <SectionHead
              tone="dark"
              eyebrow="Chapter 14 · Why we are building it"
              title="Completed work should not become a lost customer."
              lede="The service ends. The connection stays. That single idea decides what we build, what we refuse to build, and what a stranger is allowed to see when they scan a pass."
            />
          </div>
          <div className="reveal relative">
            <SealRing className="absolute inset-0 m-auto w-[94%] opacity-45" tone="saffron" />
            <div className="relative mx-auto w-[86%] max-w-[400px] py-8">
              <InteractivePass className="w-full" />
            </div>
          </div>
        </div>

        <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {principles.map((p) => (
            <Card key={p.n} tone="dark" hover className="reveal h-full">
              <Chip tone="dark">{p.n}</Chip>
              <h3 className="font-display mt-5 text-[1.2rem]">{p.title}</h3>
              <p className="mt-2.5 text-[14px] leading-relaxed text-ivory/68">{p.body}</p>
            </Card>
          ))}
        </div>
      </Container>
    </section>
  );
}

/* Pre-launch transparency ---------------------------------------------- */

export function PrelaunchTransparency() {
  const ref = useReveal<HTMLElement>();
  return (
    <section id="transparency" ref={ref} className="bg-paper py-20 sm:py-28">
      <Container>
        <div className="reveal">
          <SectionHead
            eyebrow="Chapter 15 · Where we actually are"
            title="We do not have reviews yet. The pilot has not started."
            lede="ARANCH PASS is currently a product and system concept being prepared for field validation. The pass and box shown here are approved design directions. Material tests, technician timing, provider adoption and repeat-service results still need to be proven."
          />
        </div>

        <div className="mt-12 grid gap-5 lg:grid-cols-2">
          <Card tone="cream" className="reveal">
            <h3 className="mono text-[11px] tracking-[0.18em] text-violet uppercase">What exists</h3>
            <ul className="mt-5 grid gap-2">
              {transparency.exists.map((t) => (
                <li
                  key={t}
                  className="flex items-start gap-3 rounded-[16px] bg-white/70 px-4 py-3.5 text-[15px]"
                >
                  <span
                    aria-hidden="true"
                    className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full bg-saffron text-[11px] text-plum"
                  >
                    ✓
                  </span>
                  <span className="text-ink/85">{t}</span>
                </li>
              ))}
            </ul>
          </Card>
          <Card tone="cream" className="reveal">
            <h3 className="mono text-[11px] tracking-[0.18em] text-violet uppercase">What remains</h3>
            <ul className="mt-5 grid gap-2">
              {transparency.remains.map((t) => (
                <li
                  key={t}
                  className="flex items-start gap-3 rounded-[16px] bg-white/70 px-4 py-3.5 text-[15px]"
                >
                  <span
                    aria-hidden="true"
                    className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full border border-line text-[10px] text-muted"
                  >
                    ○
                  </span>
                  <span className="text-ink/72">{t}</span>
                </li>
              ))}
            </ul>
          </Card>
        </div>

        <div className="reveal mt-5 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          <figure className="pin pin-hover overflow-hidden bg-white">
            <ImageCard img="materialTest" ratio="aspect-square" rounded="rounded-none" />
            <figcaption className="mono px-5 py-4 text-[10px] tracking-[0.1em] text-muted uppercase">
              Material & print wear study · concept
            </figcaption>
          </figure>
          <figure className="pin pin-hover overflow-hidden bg-white">
            <ImageCard img="firstBatch" ratio="aspect-square" rounded="rounded-none" />
            <figcaption className="mono px-5 py-4 text-[10px] tracking-[0.1em] text-muted uppercase">
              Print run visual · not a shipped batch
            </figcaption>
          </figure>
          <Card tone="violet" className="flex flex-col justify-between">
            <div>
              <h3 className="font-display text-[1.4rem]">Want to be in the first group?</h3>
              <p className="mt-3 text-[14px] leading-relaxed text-ivory/72">
                Pilot providers get early access, direct input on the workflow and honest updates —
                including the parts that do not work.
              </p>
            </div>
            <Button href="#pilot" variant="soft" className="mt-6 w-full">
              Apply for the first pilot
            </Button>
          </Card>
        </div>
      </Container>
    </section>
  );
}
