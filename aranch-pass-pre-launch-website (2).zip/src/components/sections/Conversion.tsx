import { useId, useState, type FormEvent } from "react";
import { Wordmark } from "@/components/Header";
import { Card, Chip, Container, ImageCard, Note, SealRing, SectionHead } from "@/components/ui";
import { faqs, footerLinks, site } from "@/data";
import { useReveal } from "@/hooks/useReveal";
import { cn } from "@/utils/cn";

/* FAQ ------------------------------------------------------------------ */

export function FAQ() {
  const ref = useReveal<HTMLElement>();
  const [open, setOpen] = useState<number | null>(0);
  const uid = useId();

  return (
    <section id="faq" ref={ref} className="bg-cream py-20 sm:py-28">
      <Container>
        <div className="grid gap-10 lg:grid-cols-[0.72fr_1.28fr] lg:gap-14">
          <div className="reveal lg:sticky lg:top-28 lg:self-start">
            <SectionHead
              eyebrow="Chapter 16 · Questions"
              title="Answered honestly, including the unfinished parts."
            />
            <Note className="mt-6">
              If an answer would need a claim we cannot support today, it says so instead.
            </Note>
            <div className="mt-8 hidden lg:block">
              <ImageCard img="loopStill" ratio="aspect-[4/5]" className="max-w-[260px]" />
            </div>
          </div>

          <ul className="reveal grid gap-2.5">
            {faqs.map((f, i) => {
              const isOpen = open === i;
              return (
                <li key={f.q} className={cn("pin overflow-hidden bg-white", isOpen && "bg-white")}>
                  <h3>
                    <button
                      type="button"
                      id={`${uid}-b-${i}`}
                      aria-expanded={isOpen}
                      aria-controls={`${uid}-p-${i}`}
                      onClick={() => setOpen(isOpen ? null : i)}
                      className="flex w-full items-start gap-4 px-5 py-5 text-left sm:px-6"
                    >
                      <span className="mono mt-1 shrink-0 text-[10px] text-violet/70">
                        {String(i + 1).padStart(2, "0")}
                      </span>
                      <span className="flex-1 text-[16px] font-bold text-deepviolet sm:text-[17px]">
                        {f.q}
                      </span>
                      <span
                        aria-hidden="true"
                        className={cn(
                          "mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-full text-[15px] transition-transform duration-300",
                          isOpen
                            ? "rotate-45 bg-saffron text-plum"
                            : "bg-violet/8 text-violet",
                        )}
                      >
                        +
                      </span>
                    </button>
                  </h3>
                  <div
                    id={`${uid}-p-${i}`}
                    role="region"
                    aria-labelledby={`${uid}-b-${i}`}
                    hidden={!isOpen}
                    className="px-5 pb-6 pl-[52px] sm:px-6 sm:pl-[62px]"
                  >
                    <p className="max-w-[68ch] text-[15px] leading-[1.7] text-ink/75">{f.a}</p>
                  </div>
                </li>
              );
            })}
          </ul>
        </div>
      </Container>
    </section>
  );
}

/* Pilot form ------------------------------------------------------------ */

type Stage = "one" | "two" | "done";

export function PilotForm() {
  const ref = useReveal<HTMLElement>();
  const uid = useId();
  const [stage, setStage] = useState<Stage>("one");
  const [contact, setContact] = useState("");
  const [error, setError] = useState<string | null>(null);

  const validContact = (v: string) =>
    /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim()) || /^[+\d][\d\s-]{7,15}$/.test(v.trim());

  const submitStageOne = (e: FormEvent) => {
    e.preventDefault();
    if (!validContact(contact)) {
      setError("Enter a valid phone number or email address so we can reach you.");
      return;
    }
    setError(null);
    /**
     * INTEGRATION BOUNDARY —
     * No backend is connected. Nothing is stored or transmitted.
     * Replace with a POST to your endpoint; validate + rate-limit + sanitise
     * server-side and store a consent timestamp and source.
     */
    setStage("two");
  };

  const inputCls =
    "w-full rounded-[16px] border border-ivory/15 bg-plum/50 px-4 py-3.5 text-[15px] text-ivory placeholder:text-ivory/35 focus:border-saffron";
  const labelCls = "mono mb-2 block text-[10px] tracking-[0.14em] text-ivory/60 uppercase";

  return (
    <section
      id="pilot"
      ref={ref}
      className="relative overflow-hidden bg-deepviolet py-20 text-ivory sm:py-28"
    >
      <SealRing
        className="pointer-events-none absolute -right-40 -bottom-40 w-[520px] opacity-20"
        tone="ivory"
        text="JOIN THE PILOT · ARANCH PASS · "
      />
      <Container className="relative">
        <div className="grid gap-12 lg:grid-cols-2 lg:gap-16">
          <div className="reveal">
            <SectionHead
              tone="dark"
              eyebrow="Chapter 17 · The pilot list"
              title="Put a way back on every completed job."
              lede="Join the pilot list for launch updates, prototype progress and the first provider-testing opportunities."
            />
            <div className="mt-10 hidden max-w-[300px] lg:block">
              <ImageCard img="activation" ratio="aspect-[4/5]" />
            </div>
          </div>

          <Card tone="dark" className="reveal h-fit">
            {stage === "one" && (
              <form onSubmit={submitStageOne} noValidate>
                <label htmlFor={`${uid}-contact`} className={labelCls}>
                  Phone or email
                </label>
                <input
                  id={`${uid}-contact`}
                  name="contact"
                  type="text"
                  autoComplete="email"
                  value={contact}
                  onChange={(e) => setContact(e.target.value)}
                  aria-invalid={!!error}
                  aria-describedby={error ? `${uid}-err` : `${uid}-consent`}
                  placeholder="you@example.com or 98XXXXXXXX"
                  className={inputCls}
                />
                {error && (
                  <p id={`${uid}-err`} role="alert" className="mt-2 text-[13px] text-saffron">
                    {error}
                  </p>
                )}
                <button
                  type="submit"
                  className="mt-5 w-full rounded-full bg-saffron px-6 py-4 text-[14px] font-semibold text-plum transition-colors hover:bg-[#ffbe22]"
                >
                  Join the pilot list
                </button>
                <a
                  href={site.whatsappHref}
                  className="mt-3 flex w-full items-center justify-center rounded-full bg-ivory/12 px-6 py-4 text-[14px] font-semibold text-ivory transition-colors hover:bg-ivory/20"
                >
                  Continue on WhatsApp
                </a>
                <p id={`${uid}-consent`} className="mono mt-5 text-[11px] leading-relaxed text-ivory/50">
                  Product and pilot updates only. No purchased lists, no fake urgency, unsubscribe
                  anytime.
                </p>
              </form>
            )}

            {stage === "two" && (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  setStage("done");
                }}
              >
                <Chip tone="dark">Step 2 of 2 · optional</Chip>
                <h3 className="font-display mt-4 text-[1.5rem]">Tell us about the business</h3>
                <div className="mt-5 grid gap-4 sm:grid-cols-2">
                  <div>
                    <label htmlFor={`${uid}-name`} className={labelCls}>
                      Your name
                    </label>
                    <input id={`${uid}-name`} name="name" className={inputCls} autoComplete="name" />
                  </div>
                  <div>
                    <label htmlFor={`${uid}-biz`} className={labelCls}>
                      Business name
                    </label>
                    <input
                      id={`${uid}-biz`}
                      name="business"
                      className={inputCls}
                      autoComplete="organization"
                    />
                  </div>
                  <div>
                    <label htmlFor={`${uid}-city`} className={labelCls}>
                      City
                    </label>
                    <input
                      id={`${uid}-city`}
                      name="city"
                      className={inputCls}
                      autoComplete="address-level2"
                    />
                  </div>
                  <div>
                    <label htmlFor={`${uid}-cat`} className={labelCls}>
                      Service category
                    </label>
                    <select id={`${uid}-cat`} name="category" className={inputCls} defaultValue="">
                      <option value="" disabled>
                        Select
                      </option>
                      <option>RO / water purifier</option>
                      <option>AC servicing</option>
                      <option>Two-wheeler</option>
                      <option>Other maintained asset</option>
                    </select>
                  </div>
                </div>
                <button
                  type="submit"
                  className="mt-6 w-full rounded-full bg-saffron px-6 py-4 text-[14px] font-semibold text-plum"
                >
                  Finish
                </button>
                <button
                  type="button"
                  onClick={() => setStage("done")}
                  className="mono mt-3 w-full rounded-full py-2 text-[11px] tracking-[0.12em] text-ivory/55 uppercase underline underline-offset-4"
                >
                  Skip for now
                </button>
              </form>
            )}

            {stage === "done" && (
              <div role="status" aria-live="polite">
                <Chip tone="saffron">Prototype</Chip>
                <h3 className="font-display mt-5 text-[1.7rem]">Noted — on this device only.</h3>
                <p className="mt-4 text-[15px] leading-relaxed text-ivory/75">
                  This site is a pre-launch prototype with no backend connected, so nothing was
                  transmitted or stored. Until the pilot list is live, write to{" "}
                  <span className="mono text-saffron">{site.contactEmail}</span> and we will add you
                  by hand.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setStage("one");
                    setContact("");
                  }}
                  className="mono mt-6 text-[11px] tracking-[0.12em] text-ivory/60 uppercase underline underline-offset-4"
                >
                  Start again
                </button>
              </div>
            )}
          </Card>
        </div>
      </Container>
    </section>
  );
}

/* Footer ---------------------------------------------------------------- */

export function Footer() {
  return (
    <footer className="bg-plum pt-16 pb-10 text-ivory">
      <Container>
        <div className="grid gap-12 lg:grid-cols-[1.2fr_1.8fr]">
          <div>
            <Wordmark tone="ivory" className="text-[22px]" />
            <p className="font-display mt-5 max-w-[18ch] text-[1.5rem] text-ivory/90">
              {site.positioning}
            </p>
            <p className="mono mt-5 text-[11px] leading-relaxed tracking-[0.08em] text-ivory/45 uppercase">
              {site.stage}
            </p>
            <a
              href={`mailto:${site.contactEmail}`}
              className="mono mt-4 inline-block text-[12px] text-ivory/60 underline underline-offset-4 hover:text-ivory"
            >
              {site.contactEmail}
            </a>
          </div>

          <div className="grid gap-8 sm:grid-cols-3">
            {footerLinks.map((col) => (
              <nav key={col.title} aria-label={col.title}>
                <h2 className="mono text-[10px] tracking-[0.18em] text-saffron uppercase">
                  {col.title}
                </h2>
                <ul className="mt-4 space-y-2.5">
                  {col.items.map((l) => (
                    <li key={l.label}>
                      <a
                        href={l.href}
                        className="text-[14px] text-ivory/65 transition-colors hover:text-ivory"
                      >
                        {l.label}
                      </a>
                    </li>
                  ))}
                </ul>
              </nav>
            ))}
          </div>
        </div>

        <p className="mono mt-14 max-w-[84ch] border-t border-ivory/15 pt-6 text-[11px] leading-relaxed text-ivory/50">
          ARANCH PASS is in pre-launch development. Product visuals may show design concepts; final
          materials and features may change after field testing. Refund, cancellation and shipping
          policies will be published if and when payments or physical orders are enabled.
        </p>
        <p className="mono mt-4 text-[11px] tracking-[0.1em] text-ivory/40 uppercase">
          © {new Date().getFullYear()} ARANCH PASS
        </p>
      </Container>
    </footer>
  );
}
