import { Card, Chip, Container, ImageCard, Note, SealRing, SectionHead } from "@/components/ui";
import { compareColumns, compareRows, privacyRows, roadmap, segments, type CompareValue } from "@/data";
import { useReveal } from "@/hooks/useReveal";
import { cn } from "@/utils/cn";

/* Public vs private -------------------------------------------------- */

export function PrivacyTable() {
  const ref = useReveal<HTMLElement>();
  return (
    <section id="privacy" ref={ref} className="bg-plum py-20 text-ivory sm:py-28">
      <Container>
        <div className="reveal">
          <SectionHead
            tone="dark"
            eyebrow="Chapter 09 · Data boundaries"
            title="Useful in public. Protected by default."
            aside={
              <Note tone="dark" className="lg:text-right">
                Privacy-led by design, and still subject to a production security review. We do not
                claim it is “100% secure”.
              </Note>
            }
          />
        </div>

        <div className="mt-12 grid gap-4 md:grid-cols-2">
          <Card tone="dark" pad="p-0" className="reveal overflow-hidden">
            <h3 className="mono border-b border-ivory/12 px-6 py-4 text-[11px] tracking-[0.18em] text-saffron uppercase">
              Public after scan
            </h3>
            <ul className="p-2">
              {privacyRows.map((r) => (
                <li
                  key={r.public}
                  className="flex items-center gap-3 rounded-[16px] px-4 py-3.5 text-[15px] transition-colors hover:bg-ivory/6"
                >
                  <span
                    aria-hidden="true"
                    className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-saffron text-[12px] text-plum"
                  >
                    ✓
                  </span>
                  {r.public}
                </li>
              ))}
            </ul>
          </Card>

          <Card tone="dark" pad="p-0" className="reveal overflow-hidden">
            <h3 className="mono border-b border-ivory/12 px-6 py-4 text-[11px] tracking-[0.18em] text-ivory/70 uppercase">
              Private / verified only
            </h3>
            <ul className="p-2">
              {privacyRows.map((r) => (
                <li
                  key={r.private}
                  className="flex items-center gap-3 rounded-[16px] px-4 py-3.5 text-[15px] text-ivory/72 transition-colors hover:bg-ivory/6"
                >
                  <span
                    aria-hidden="true"
                    className="grid h-6 w-6 shrink-0 place-items-center rounded-full border border-ivory/35 text-[11px]"
                  >
                    ✕
                  </span>
                  {r.private}
                </li>
              ))}
            </ul>
          </Card>
        </div>
      </Container>
    </section>
  );
}

/* Category roadmap ---------------------------------------------------- */

function CategoryGlyph({ i }: { i: number }) {
  return (
    <svg viewBox="0 0 120 96" className="h-20 w-full" aria-hidden="true">
      <g fill="none" stroke="#4D1688" strokeWidth="1.8" strokeLinecap="round">
        {i === 0 && (
          <>
            <rect x="36" y="10" width="48" height="76" rx="14" />
            <rect x="46" y="22" width="28" height="20" rx="6" stroke="#F4AD08" />
            <path d="M46 58 h28 M46 68 h18" opacity="0.45" />
          </>
        )}
        {i === 1 && (
          <>
            <rect x="18" y="22" width="84" height="32" rx="12" />
            <path d="M28 64 q10 12 20 0 M54 64 q10 12 20 0 M80 64 q9 12 15 0" stroke="#F4AD08" />
            <path d="M28 38 h64" opacity="0.45" />
          </>
        )}
        {i === 2 && (
          <>
            <circle cx="32" cy="66" r="15" />
            <circle cx="90" cy="66" r="15" />
            <path d="M32 66 l18 -26 h26 l14 26" stroke="#F4AD08" />
            <path d="M50 40 h22" />
          </>
        )}
      </g>
    </svg>
  );
}

export function CategoryRoadmap() {
  const ref = useReveal<HTMLElement>();
  return (
    <section id="roadmap" ref={ref} className="bg-cream py-20 sm:py-28">
      <Container>
        <div className="reveal">
          <SectionHead
            eyebrow="Chapter 10 · Roadmap"
            title="Start with one service. Build for every maintained asset."
            lede="Only one category is intended for the first pilot. Nothing here should be read as all three being operational."
          />
        </div>

        <div className="mt-12 grid gap-5 md:grid-cols-3">
          {roadmap.map((c, i) => (
            <Card
              key={c.code}
              hover
              tone={c.tone === "first" ? "light" : "cream"}
              className={cn("reveal h-full", c.tone !== "first" && "ring-1 ring-line")}
            >
              <div className="flex items-center justify-between gap-2">
                <Chip>{c.code}</Chip>
                <Chip tone={c.tone === "first" ? "saffron" : "light"}>{c.status}</Chip>
              </div>
              <CategoryGlyph i={i} />
              <h3 className="font-display mt-4 text-[1.4rem] text-deepviolet">{c.title}</h3>
              <p className="mt-2.5 text-[14px] leading-relaxed text-ink/70">{c.body}</p>
            </Card>
          ))}
        </div>
      </Container>
    </section>
  );
}

/* Comparison ---------------------------------------------------------- */

function Mark({ v }: { v: CompareValue }) {
  const map = {
    yes: { t: "Yes", c: "bg-saffron text-plum" },
    varies: { t: "Varies", c: "bg-violet/10 text-violet" },
    no: { t: "No", c: "bg-transparent text-muted ring-1 ring-line" },
  }[v];
  return (
    <span
      className={cn(
        "mono inline-block min-w-[62px] rounded-full px-3 py-1.5 text-center text-[10px] tracking-[0.08em] uppercase",
        map.c,
      )}
    >
      {map.t}
    </span>
  );
}

export function ComparisonTable() {
  const ref = useReveal<HTMLElement>();
  return (
    <section ref={ref} className="bg-paper py-20 sm:py-28">
      <Container>
        <div className="reveal">
          <SectionHead
            eyebrow="Chapter 11 · Positioning"
            title="More useful than a static sticker. Lighter than a full CRM."
          />
        </div>

        {/* desktop table */}
        <div className="reveal mt-12 hidden md:block">
          <Card pad="p-0" className="overflow-hidden">
            <div className="scroll-x">
              <table className="w-full min-w-[760px] border-collapse text-left">
                <caption className="sr-only">
                  Comparison of notebook or WhatsApp, static number stickers, field-service CRMs and
                  ARANCH PASS
                </caption>
                <thead>
                  <tr>
                    <th scope="col" className="w-[34%] px-6 py-5 align-bottom">
                      <span className="mono text-[10px] tracking-[0.14em] text-muted uppercase">
                        Capability
                      </span>
                    </th>
                    {compareColumns.map((c, i) => (
                      <th
                        key={c}
                        scope="col"
                        className={cn(
                          "px-4 py-5 align-bottom",
                          i === compareColumns.length - 1 && "bg-cream",
                        )}
                      >
                        <span
                          className={cn(
                            "block text-[13px] leading-tight font-bold",
                            i === compareColumns.length - 1 ? "text-deepviolet" : "text-muted",
                          )}
                        >
                          {c}
                        </span>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {compareRows.map((r) => (
                    <tr key={r.label} className="border-t border-line">
                      <th
                        scope="row"
                        className="px-6 py-4 text-[14px] font-medium text-ink/85"
                      >
                        {r.label}
                      </th>
                      {r.values.map((v, i) => (
                        <td
                          key={i}
                          className={cn("px-4 py-4", i === r.values.length - 1 && "bg-cream")}
                        >
                          <Mark v={v} />
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>

        {/* mobile: one card per capability */}
        <div className="reveal mt-10 grid gap-3 md:hidden">
          {compareRows.map((r) => (
            <Card key={r.label} pad="p-5">
              <h3 className="text-[15px] font-bold text-deepviolet">{r.label}</h3>
              <dl className="mt-3 grid gap-2">
                {compareColumns.map((c, i) => (
                  <div key={c} className="flex items-center justify-between gap-3">
                    <dt
                      className={cn(
                        "text-[13px]",
                        i === compareColumns.length - 1
                          ? "font-semibold text-deepviolet"
                          : "text-muted",
                      )}
                    >
                      {c}
                    </dt>
                    <dd>
                      <Mark v={r.values[i]} />
                    </dd>
                  </div>
                ))}
              </dl>
            </Card>
          ))}
        </div>

        <Note className="mt-5">
          Category-level positioning; individual products vary. Marks describe typical behaviour of
          a category, not any specific vendor.
        </Note>
      </Container>
    </section>
  );
}

/* Provider segments --------------------------------------------------- */

export function ProviderSegments() {
  const ref = useReveal<HTMLElement>();
  return (
    <section
      id="providers"
      ref={ref}
      className="relative overflow-hidden bg-deepviolet py-20 text-ivory sm:py-28"
    >
      <SealRing
        className="pointer-events-none absolute -top-32 -left-28 w-[380px] opacity-15"
        tone="ivory"
        text="FOR SERVICE BUSINESSES · "
      />
      <Container className="relative">
        <div className="reveal">
          <SectionHead
            tone="dark"
            eyebrow="Chapter 12 · Who it is for"
            title="Built around how service work actually ends."
            aside={
              <div className="hidden lg:block">
                <ImageCard img="attached" ratio="aspect-[4/5]" className="w-[190px]" />
              </div>
            }
          />
        </div>

        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {segments.map((s) => (
            <Card key={s.code} tone="dark" hover className="reveal group h-full">
              <div className="flex items-center justify-between">
                <Chip tone="dark">{s.code}</Chip>
                <span
                  aria-hidden="true"
                  className="h-2.5 w-2.5 rounded-full bg-ivory/25 transition-colors group-hover:bg-saffron"
                />
              </div>
              <h3 className="font-display mt-6 text-[1.3rem]">{s.title}</h3>
              <p className="mt-3 text-[14px] leading-relaxed text-ivory/70">{s.body}</p>
            </Card>
          ))}
        </div>
      </Container>
    </section>
  );
}
