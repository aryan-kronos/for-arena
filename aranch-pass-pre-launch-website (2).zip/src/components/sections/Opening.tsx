import { InteractivePass } from "@/components/InteractivePass";
import {
  Button,
  Card,
  Chip,
  Container,
  Eyebrow,
  ImageCard,
  Note,
  Pin,
  SealRing,
  SectionHead,
  TraceLine,
} from "@/components/ui";
import { bandItems, loopBoard, manifestoLines } from "@/data";
import { useReveal } from "@/hooks/useReveal";

export function Hero() {
  const ref = useReveal<HTMLElement>();
  return (
    <section id="top" ref={ref} className="relative overflow-hidden bg-paper pt-[92px] pb-14 sm:pt-[116px] sm:pb-20">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-40 -right-40 h-[560px] w-[560px] rounded-full bg-saffron/16 blur-[10px]"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -bottom-52 -left-32 h-[420px] w-[420px] rounded-full bg-violet/8"
      />

      <Container className="relative">
        <div className="grid items-center gap-12 lg:grid-cols-[1.02fr_0.98fr] lg:gap-8">
          <div className="reveal">
            <Eyebrow>Physical service identity · built for India</Eyebrow>
            <h1 className="font-display balance mt-6 text-[clamp(2.15rem,8.2vw,5rem)] text-deepviolet">
              Every service should leave{" "}
              <span className="relative inline-block">
                <span className="relative z-10">a way back.</span>
                <span
                  aria-hidden="true"
                  className="absolute inset-x-[-6px] bottom-[6px] z-0 h-[38%] rounded-full bg-saffron/60"
                />
              </span>
            </h1>
            <p className="mt-7 max-w-[52ch] text-[17px] leading-[1.68] text-ink/75 sm:text-[19px]">
              ARANCH PASS gives every serviced asset a unique physical identity — so technicians
              can record the job, and customers can find the original provider again.
            </p>

            <div className="mt-9 flex flex-wrap items-center gap-3">
              <Button href="#pilot" size="lg">
                Join the pilot
              </Button>
              <Button href="#system" variant="ghost" size="lg">
                See the system →
              </Button>
            </div>

            <div className="mt-10 flex flex-wrap items-center gap-2">
              <Chip>Pre-launch</Chip>
              <Chip>First pilots being designed</Chip>
              <Chip>No customer app required</Chip>
            </div>

            <TraceLine className="mt-8 h-8 w-full max-w-[520px]" />
          </div>

          <div className="reveal relative">
            <div
              aria-hidden="true"
              className="absolute top-1/2 left-1/2 aspect-square w-[84%] -translate-x-1/2 -translate-y-1/2 rounded-full bg-saffron"
            />
            <SealRing
              className="pointer-events-none absolute top-1/2 left-1/2 aspect-square w-[100%] -translate-x-1/2 -translate-y-1/2 opacity-60"
              tone="violet"
            />
            <div className="relative px-1 py-10 sm:px-6">
              <InteractivePass className="mx-auto w-full max-w-[470px]" priority />
            </div>
            <div className="relative mx-auto flex max-w-[470px] flex-wrap items-center justify-between gap-2">
              <Chip tone="violet">Concept visual</Chip>
              <span className="mono text-[11px] tracking-[0.14em] text-violet/70 uppercase">
                AP-7K3M9 · 01/50
              </span>
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}

export function TraceBand() {
  const row = [...bandItems, ...bandItems, ...bandItems];
  return (
    <section aria-label="The ARANCH PASS service loop" className="bg-deepviolet py-5 sm:py-6">
      <div className="marquee">
        <div className="marquee-track items-center">
          {[0, 1].map((dup) => (
            <div key={dup} className="flex items-center" aria-hidden={dup === 1}>
              {row.map((item, i) => (
                <span key={`${dup}-${i}`} className="flex shrink-0 items-center gap-6 pr-6">
                  <span className="font-display text-[clamp(1.05rem,2.4vw,1.7rem)] whitespace-nowrap text-ivory">
                    {item}
                  </span>
                  <span aria-hidden="true" className="h-1.5 w-1.5 rounded-full bg-saffron" />
                </span>
              ))}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export function ProblemManifesto() {
  const ref = useReveal<HTMLElement>();
  return (
    <section ref={ref} className="relative overflow-hidden bg-plum py-20 text-ivory sm:py-28">
      <SealRing
        className="pointer-events-none absolute -top-28 -right-28 w-[420px] opacity-15"
        tone="ivory"
        text="LOST CONTACT · LOST HISTORY · "
      />
      <Container className="relative">
        <div className="reveal">
          <SectionHead
            tone="dark"
            eyebrow="Chapter 01 · The problem"
            title={
              <>
                The job gets completed.{" "}
                <span className="text-ivory/45">The customer connection gets lost.</span>
              </>
            }
          />
        </div>

        <div className="mt-14 grid gap-4 sm:grid-cols-2">
          {manifestoLines.map((line, i) => (
            <Card key={line} tone="dark" hover className="reveal flex items-start gap-5">
              <span className="mono mt-1 shrink-0 rounded-full bg-saffron px-2.5 py-1 text-[11px] text-plum">
                {String(i + 1).padStart(2, "0")}
              </span>
              <p className="text-[clamp(1.05rem,2.6vw,1.45rem)] leading-snug text-ivory/90">
                {line}
              </p>
            </Card>
          ))}
        </div>

        <div className="reveal mt-12 grid gap-8 lg:grid-cols-[1.1fr_0.9fr] lg:items-end">
          <p className="font-display balance text-[clamp(1.5rem,4vw,2.5rem)] text-saffron">
            ARANCH PASS keeps a way back attached to the asset itself.
          </p>
          <Note tone="dark">
            No statistics appear in this section on purpose. We have not run a field study yet, and
            we will not publish numbers we cannot source.
          </Note>
        </div>
      </Container>
    </section>
  );
}

/** Pinterest-style board: the whole loop, saved as pins. */
export function LoopBoard() {
  const ref = useReveal<HTMLElement>();
  return (
    <section ref={ref} className="bg-cream py-20 sm:py-28">
      <Container>
        <div className="reveal">
          <SectionHead
            eyebrow="Chapter 02 · The loop"
            title="Attach, record, scan, rebook."
            lede="One physical object carries a completed job forward. These are concept visuals of how the loop is intended to work in the field."
            aside={<Chip tone="saffron">Concept board</Chip>}
          />
        </div>

        <div className="board mt-12">
          {loopBoard.map((p) => (
            <div key={p.title} className="reveal">
              <Pin img={p.img} ratio={p.ratio} tag={p.tag} title={p.title} body={p.body} />
            </div>
          ))}
        </div>
        <Note className="mt-6">
          Studio and concept photography. Not evidence of a completed pilot or a shipped production
          batch.
        </Note>
      </Container>
    </section>
  );
}

export function TwoSides() {
  const ref = useReveal<HTMLElement>();
  return (
    <section ref={ref} className="bg-paper py-20 sm:py-28">
      <Container>
        <div className="reveal">
          <SectionHead
            eyebrow="Chapter 03 · Two sides, one pass"
            title="The same pass does two different jobs."
          />
        </div>

        <div className="mt-12 grid gap-6 lg:grid-cols-2">
          <Card tone="cream" hover pad="p-0" className="reveal overflow-hidden">
            <ImageCard img="closeup" ratio="aspect-[16/10]" rounded="rounded-none" />
            <div className="p-6 sm:p-8">
              <Chip>Side A · Provider</Chip>
              <h3 className="font-display mt-5 text-[clamp(1.4rem,3.2vw,2rem)] text-deepviolet">
                The technician finishes the job.
              </h3>
              <p className="mt-3.5 max-w-[44ch] leading-relaxed text-ink/72">
                Scan the pass, record the service and set the next recommended date. The asset is
                now connected to the provider’s system.
              </p>
            </div>
          </Card>

          <Card tone="violet" hover pad="p-0" className="reveal overflow-hidden">
            <ImageCard img="returnScan" ratio="aspect-[16/10]" rounded="rounded-none" />
            <div className="p-6 sm:p-8">
              <Chip tone="saffron">Side B · Customer</Chip>
              <h3 className="font-display mt-5 text-[clamp(1.4rem,3.2vw,2rem)]">
                The customer needs help again.
              </h3>
              <p className="mt-3.5 max-w-[44ch] leading-relaxed text-ivory/75">
                Scan the same pass, see safe service information and contact the original provider
                without searching from zero.
              </p>
            </div>
          </Card>
        </div>
      </Container>
    </section>
  );
}
