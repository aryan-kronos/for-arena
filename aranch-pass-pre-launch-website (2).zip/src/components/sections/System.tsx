import { useId, useState } from "react";
import { Card, Chip, Container, Note, SectionHead } from "@/components/ui";
import { useReveal } from "@/hooks/useReveal";
import { cn } from "@/utils/cn";

const tabs = [
  { id: "tech", label: "Technician view" },
  { id: "scan", label: "Public scan page" },
  { id: "dash", label: "Provider dashboard" },
] as const;

type TabId = (typeof tabs)[number]["id"];

function DemoChrome({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <Card pad="p-0" className="overflow-hidden">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line bg-cream px-5 py-3.5">
        <span className="mono text-[10px] tracking-[0.14em] text-violet uppercase">{title}</span>
        <Chip tone="saffron">Demo · mock data</Chip>
      </div>
      <div className="p-4 sm:p-6">{children}</div>
    </Card>
  );
}

function Field({
  label,
  value,
  privateField,
  wide,
}: {
  label: string;
  value: string;
  privateField?: boolean;
  wide?: boolean;
}) {
  return (
    <div className={cn(wide && "sm:col-span-2")}>
      <div className="mono flex items-center gap-2 text-[9px] tracking-[0.14em] text-muted uppercase">
        {label}
        {privateField && (
          <span className="rounded-full bg-deepviolet px-2 py-0.5 text-[8px] text-ivory">
            private
          </span>
        )}
      </div>
      <div className="mt-1.5 rounded-[14px] bg-cream px-4 py-3 text-[14px] text-ink/85">{value}</div>
    </div>
  );
}

function TechnicianView() {
  const [more, setMore] = useState(false);
  return (
    <DemoChrome title="Record a service · AP-7K3M9">
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Customer" value="Search or create — R. K. (saved)" />
        <Field label="Asset category" value="RO / water purifier" />
        <Field label="Service type" value="Filter replacement + sanitisation" />
        <Field label="Service date" value="Today" />
        <Field label="Amount paid" value="₹ ——" privateField />
        <Field label="Next recommended service" value="+ 6 months" />
        <Field label="Work summary (public)" value="Sediment and carbon filters replaced." wide />
        <Field label="Technician" value="Filled automatically from login" wide />
      </div>
      <button
        type="button"
        onClick={() => setMore((v) => !v)}
        aria-expanded={more}
        className="mono mt-4 flex w-full items-center justify-between rounded-full bg-violet/8 px-5 py-3 text-[11px] tracking-[0.12em] text-violet uppercase transition-colors hover:bg-violet/14"
      >
        Add more details
        <span aria-hidden="true">{more ? "−" : "+"}</span>
      </button>
      {more && (
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <Field label="Private notes" value="Pressure low at inlet — monitor." privateField />
          <Field label="Parts used" value="SED-10, CTO-10" />
          <Field label="Warranty reference" value="—" />
          <Field label="Attachment" value="Invoice image" privateField />
        </div>
      )}
      <div className="mt-5 flex flex-wrap gap-2">
        <span className="mono rounded-full bg-deepviolet px-5 py-3 text-[11px] tracking-[0.1em] text-paper uppercase">
          Save service
        </span>
        <span className="mono rounded-full bg-violet/10 px-5 py-3 text-[11px] tracking-[0.1em] text-violet uppercase">
          Save & attach pass
        </span>
      </div>
    </DemoChrome>
  );
}

function ScanView() {
  const rows: [string, string][] = [
    ["Asset", "RO purifier · kitchen unit"],
    ["Asset code", "AP-7K3M9"],
    ["Last service", "Recorded by provider"],
    ["Next recommended", "Set at last service"],
    ["Work summary", "Sediment and carbon filters replaced."],
  ];
  return (
    <DemoChrome title="Public scan · what anyone sees">
      <div className="mx-auto max-w-[410px]">
        <div className="rounded-[22px] bg-deepviolet p-5 text-ivory">
          <p className="mono text-[9px] tracking-[0.18em] text-saffron uppercase">Serviced by</p>
          <p className="font-display mt-2 text-[1.5rem]">Sample Aqua Services</p>
          <p className="mono mt-1 text-[11px] text-ivory/60">Provider · public contact shown</p>
        </div>
        <dl className="mt-3 grid gap-1.5">
          {rows.map(([k, v]) => (
            <div
              key={k}
              className="flex flex-wrap justify-between gap-2 rounded-[16px] bg-cream px-4 py-3"
            >
              <dt className="mono text-[10px] tracking-[0.12em] text-muted uppercase">{k}</dt>
              <dd className="text-right text-[14px] text-ink/85">{v}</dd>
            </div>
          ))}
        </dl>
        <div className="mt-3 grid grid-cols-2 gap-2">
          <span className="mono rounded-full bg-saffron px-3 py-3.5 text-center text-[11px] tracking-[0.08em] text-plum uppercase">
            WhatsApp
          </span>
          <span className="mono rounded-full bg-deepviolet px-3 py-3.5 text-center text-[11px] tracking-[0.08em] text-ivory uppercase">
            Call provider
          </span>
        </div>
        <p className="mono mt-3 rounded-[16px] bg-violet/6 px-4 py-3 text-[10px] leading-relaxed text-muted">
          Full history? Verify as the customer (planned: OTP). No customer name, phone, address or
          amount is shown on a public scan.
        </p>
      </div>
    </DemoChrome>
  );
}

function DashboardView() {
  const stats: [string, string][] = [
    ["Active passes", "—"],
    ["Services due", "—"],
    ["Technicians", "—"],
    ["Passes in stock", "—"],
  ];
  const events: [string, string, string][] = [
    ["AP-7K3M9", "Filter replacement", "Technician A"],
    ["AP-2R8QD", "Installation", "Technician B"],
    ["AP-9V4XL", "Sanitisation", "Technician A"],
  ];
  return (
    <DemoChrome title="Provider dashboard">
      <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
        {stats.map(([k, v]) => (
          <div key={k} className="rounded-[18px] bg-cream px-4 py-4">
            <div className="font-display text-[1.7rem] text-deepviolet">{v}</div>
            <div className="mono mt-1 text-[9px] tracking-[0.12em] text-muted uppercase">{k}</div>
          </div>
        ))}
      </div>
      <div className="mt-3 grid gap-3 lg:grid-cols-[1.3fr_0.7fr]">
        <div className="rounded-[18px] bg-cream p-2">
          <div className="mono px-3 py-2 text-[9px] tracking-[0.14em] text-violet uppercase">
            Recent service events
          </div>
          <ul className="grid gap-1.5">
            {events.map(([code, type, who]) => (
              <li
                key={code}
                className="flex flex-wrap items-center justify-between gap-2 rounded-[14px] bg-white px-4 py-3"
              >
                <span className="mono text-[11px] text-violet">{code}</span>
                <span className="text-[13px] text-ink/80">{type}</span>
                <span className="mono text-[10px] text-muted uppercase">{who}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="rounded-[18px] bg-cream p-2">
          <div className="mono px-3 py-2 text-[9px] tracking-[0.14em] text-violet uppercase">
            Rebooking requests
          </div>
          <ul className="grid gap-1.5">
            {["Scan → WhatsApp", "Scan → call back", "Scan → due reminder"].map((r) => (
              <li
                key={r}
                className="mono flex items-center gap-2 rounded-[14px] bg-white px-4 py-3 text-[12px] text-ink/70"
              >
                <span aria-hidden="true" className="h-1.5 w-1.5 rounded-full bg-saffron" />
                {r}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </DemoChrome>
  );
}

export function SystemViews() {
  const ref = useReveal<HTMLElement>();
  const [tab, setTab] = useState<TabId>("tech");
  const uid = useId();

  const onKeyDown = (e: React.KeyboardEvent) => {
    const i = tabs.findIndex((t) => t.id === tab);
    if (e.key === "ArrowRight" || e.key === "ArrowLeft") {
      e.preventDefault();
      const next = (i + (e.key === "ArrowRight" ? 1 : tabs.length - 1)) % tabs.length;
      setTab(tabs[next].id);
      document.getElementById(`${uid}-${tabs[next].id}-tab`)?.focus();
    }
  };

  return (
    <section id="system" ref={ref} className="bg-cream py-20 sm:py-28">
      <Container>
        <div className="reveal">
          <SectionHead
            eyebrow="Chapter 08 · The software"
            title="One physical pass. Three simple views."
            aside={
              <Note className="lg:text-right">
                Coded front-end prototypes with mock data. Nothing is saved and no live records
                exist.
              </Note>
            }
          />
        </div>

        <div className="reveal mt-10">
          <div
            role="tablist"
            aria-label="Software views"
            onKeyDown={onKeyDown}
            className="flex flex-wrap gap-2"
          >
            {tabs.map((t) => (
              <button
                key={t.id}
                id={`${uid}-${t.id}-tab`}
                role="tab"
                type="button"
                aria-selected={tab === t.id}
                aria-controls={`${uid}-${t.id}-panel`}
                tabIndex={tab === t.id ? 0 : -1}
                onClick={() => setTab(t.id)}
                className={cn(
                  "rounded-full px-5 py-3 text-[13px] font-semibold transition-colors",
                  tab === t.id
                    ? "bg-deepviolet text-paper"
                    : "bg-violet/8 text-deepviolet hover:bg-violet/14",
                )}
              >
                {t.label}
              </button>
            ))}
          </div>

          <div className="mt-5">
            {tabs.map((t) => (
              <div
                key={t.id}
                role="tabpanel"
                id={`${uid}-${t.id}-panel`}
                aria-labelledby={`${uid}-${t.id}-tab`}
                hidden={tab !== t.id}
                tabIndex={0}
              >
                {t.id === "tech" && <TechnicianView />}
                {t.id === "scan" && <ScanView />}
                {t.id === "dash" && <DashboardView />}
              </div>
            ))}
          </div>
        </div>
      </Container>
    </section>
  );
}
