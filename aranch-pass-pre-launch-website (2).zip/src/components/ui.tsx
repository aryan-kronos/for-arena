import type { ReactNode } from "react";
import { cn } from "@/utils/cn";
import { alts, assets } from "@/data";

export function Container({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div className={cn("mx-auto w-full max-w-[1280px] px-5 sm:px-8 lg:px-12", className)}>
      {children}
    </div>
  );
}

/** Rounded Pinterest-style pill label. */
export function Chip({
  children,
  tone = "light",
  className,
}: {
  children: ReactNode;
  tone?: "light" | "dark" | "saffron" | "violet";
  className?: string;
}) {
  const tones = {
    light: "bg-violet/8 text-violet",
    dark: "bg-ivory/12 text-ivory",
    saffron: "bg-saffron text-plum",
    violet: "bg-deepviolet text-ivory",
  }[tone];
  return (
    <span
      className={cn(
        "mono inline-flex items-center gap-2 rounded-full px-3.5 py-1.5 text-[10px] font-medium tracking-[0.16em] whitespace-nowrap uppercase sm:text-[11px]",
        tones,
        className,
      )}
    >
      {children}
    </span>
  );
}

export function Eyebrow({
  children,
  tone = "light",
  className,
}: {
  children: ReactNode;
  tone?: "light" | "dark";
  className?: string;
}) {
  return (
    <p className={cn("flex", className)}>
      <Chip tone={tone === "light" ? "light" : "dark"}>
        <span
          aria-hidden="true"
          className="inline-block h-[6px] w-[6px] rounded-full bg-saffron"
        />
        {children}
      </Chip>
    </p>
  );
}

type BtnProps = {
  children: ReactNode;
  href?: string;
  onClick?: () => void;
  variant?: "primary" | "ghost" | "dark" | "outlineLight" | "soft";
  size?: "md" | "lg";
  className?: string;
  type?: "button" | "submit";
};

export function Button({
  children,
  href,
  onClick,
  variant = "primary",
  size = "md",
  className,
  type = "button",
}: BtnProps) {
  const base =
    "inline-flex items-center justify-center gap-2 rounded-full font-semibold tracking-[0.02em] transition-[transform,background-color,color,box-shadow] duration-200 active:scale-[0.98]";
  const sizes = { md: "px-6 py-3.5 text-[14px]", lg: "px-8 py-4.5 text-[15px]" }[size];
  const styles = {
    primary: "bg-deepviolet text-paper hover:bg-violet shadow-[0_10px_24px_-14px_rgba(46,7,89,0.8)]",
    dark: "bg-plum text-ivory hover:bg-deepviolet",
    soft: "bg-saffron text-plum hover:bg-[#ffbe22]",
    ghost: "bg-violet/8 text-deepviolet hover:bg-violet/14",
    outlineLight: "bg-ivory/12 text-ivory hover:bg-ivory/20",
  }[variant];
  const cls = cn(base, sizes, styles, className);
  if (href)
    return (
      <a href={href} className={cls}>
        {children}
      </a>
    );
  return (
    <button type={type} onClick={onClick} className={cls}>
      {children}
    </button>
  );
}

/**
 * Pinterest pin: image-first rounded card with an optional caption block.
 * `note` is always rendered for product visuals so concept imagery is never
 * mistaken for production evidence.
 */
export function Pin({
  img,
  ratio = "aspect-[4/5]",
  tag,
  title,
  body,
  note,
  tone = "light",
  className,
  priority = false,
}: {
  img: keyof typeof assets;
  ratio?: string;
  tag?: string;
  title?: string;
  body?: string;
  note?: string;
  tone?: "light" | "dark";
  className?: string;
  priority?: boolean;
}) {
  return (
    <figure
      className={cn(
        "pin pin-hover overflow-hidden",
        tone === "dark" ? "bg-plum/60 ring-1 ring-ivory/12" : "bg-white",
        className,
      )}
    >
      <div className={cn("pin-media", ratio)}>
        <img
          src={assets[img]}
          alt={alts[img]}
          loading={priority ? "eager" : "lazy"}
          decoding="async"
          draggable={false}
        />
        {tag && (
          <span className="pointer-events-none absolute top-3 left-3">
            <Chip tone="saffron">{tag}</Chip>
          </span>
        )}
      </div>
      {(title || body || note) && (
        <figcaption className="px-5 pt-4 pb-5">
          {title && (
            <h3
              className={cn(
                "text-[16px] leading-snug font-bold",
                tone === "dark" ? "text-ivory" : "text-deepviolet",
              )}
            >
              {title}
            </h3>
          )}
          {body && (
            <p
              className={cn(
                "mt-1.5 text-[14px] leading-relaxed",
                tone === "dark" ? "text-ivory/70" : "text-ink/70",
              )}
            >
              {body}
            </p>
          )}
          {note && (
            <p
              className={cn(
                "mono mt-3 text-[10px] tracking-[0.1em] uppercase",
                tone === "dark" ? "text-ivory/45" : "text-muted",
              )}
            >
              {note}
            </p>
          )}
        </figcaption>
      )}
    </figure>
  );
}

/** Simple rounded image block without caption chrome. */
export function ImageCard({
  img,
  ratio = "aspect-[4/5]",
  className,
  rounded = "rounded-[26px]",
  priority = false,
}: {
  img: keyof typeof assets;
  ratio?: string;
  className?: string;
  rounded?: string;
  priority?: boolean;
}) {
  return (
    <div className={cn("pin-media", ratio, rounded, className)}>
      <img
        src={assets[img]}
        alt={alts[img]}
        loading={priority ? "eager" : "lazy"}
        decoding="async"
        draggable={false}
      />
    </div>
  );
}

export function Card({
  children,
  tone = "light",
  className,
  hover = false,
  pad = "p-6 sm:p-8",
}: {
  children: ReactNode;
  tone?: "light" | "cream" | "dark" | "violet";
  className?: string;
  hover?: boolean;
  /** Full padding utility string; pass "" or "p-0" for edge-to-edge content. */
  pad?: string;
}) {
  const tones = {
    light: "bg-white",
    cream: "bg-cream",
    dark: "bg-plum/55 ring-1 ring-ivory/12 text-ivory",
    violet: "bg-deepviolet text-ivory",
  }[tone];
  return (
    <div className={cn("pin", pad, tones, hover && "pin-hover", className)}>{children}</div>
  );
}

/** Circular passport-seal ring device. Decorative only. */
export function SealRing({
  className,
  text = "ARANCH PASS · SERVICE IDENTITY · ",
  tone = "violet",
  spin = true,
}: {
  className?: string;
  text?: string;
  tone?: "violet" | "ivory" | "saffron";
  spin?: boolean;
}) {
  const color =
    tone === "violet" ? "#4D1688" : tone === "ivory" ? "rgba(247,240,216,0.85)" : "#F4AD08";
  const id = `seal-${tone}-${text.length}`;
  return (
    <svg viewBox="0 0 200 200" className={className} aria-hidden="true" focusable="false">
      <defs>
        <path id={id} d="M100,100 m-76,0 a76,76 0 1,1 152,0 a76,76 0 1,1 -152,0" fill="none" />
      </defs>
      <circle cx="100" cy="100" r="94" fill="none" stroke={color} strokeWidth="1.2" opacity="0.45" />
      <circle cx="100" cy="100" r="60" fill="none" stroke={color} strokeWidth="1.2" opacity="0.35" />
      <g className={spin ? "seal-spin" : undefined}>
        <text fill={color} fontSize="12" letterSpacing="3.6" fontFamily="IBM Plex Mono, monospace">
          <textPath href={`#${id}`}>{text.repeat(3)}</textPath>
        </text>
      </g>
    </svg>
  );
}

/** Trace line: service event → asset → provider. */
export function TraceLine({
  className,
  tone = "violet",
}: {
  className?: string;
  tone?: "violet" | "ivory";
}) {
  const c = tone === "violet" ? "#4D1688" : "rgba(247,240,216,0.7)";
  return (
    <svg viewBox="0 0 600 40" className={className} aria-hidden="true" focusable="false">
      <line x1="8" y1="20" x2="592" y2="20" stroke={c} strokeWidth="1" opacity="0.3" />
      <line x1="8" y1="20" x2="592" y2="20" stroke="#F4AD08" strokeWidth="2" className="trace-dash" />
      {[8, 300, 592].map((x) => (
        <g key={x}>
          <circle cx={x} cy="20" r="7" fill="none" stroke={c} strokeWidth="1.4" />
          <circle cx={x} cy="20" r="2.5" fill="#F4AD08" />
        </g>
      ))}
    </svg>
  );
}

export function Note({
  children,
  tone = "light",
  className,
}: {
  children: ReactNode;
  tone?: "light" | "dark";
  className?: string;
}) {
  return (
    <p
      className={cn(
        "mono max-w-[64ch] text-[11px] leading-relaxed tracking-[0.03em]",
        tone === "light" ? "text-muted" : "text-ivory/55",
        className,
      )}
    >
      {children}
    </p>
  );
}

export function SectionHead({
  eyebrow,
  title,
  lede,
  tone = "light",
  aside,
  className,
}: {
  eyebrow: string;
  title: ReactNode;
  lede?: ReactNode;
  tone?: "light" | "dark";
  aside?: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("grid gap-6 lg:grid-cols-[minmax(0,1fr)_auto] lg:items-end", className)}>
      <div className="max-w-[46rem]">
        <Eyebrow tone={tone}>{eyebrow}</Eyebrow>
        <h2
          className={cn(
            "font-display balance mt-5 text-[clamp(1.9rem,5.2vw,3.4rem)]",
            tone === "light" ? "text-deepviolet" : "text-ivory",
          )}
        >
          {title}
        </h2>
        {lede && (
          <p
            className={cn(
              "mt-5 max-w-[54ch] text-[16px] leading-[1.7] sm:text-[17px]",
              tone === "light" ? "text-ink/72" : "text-ivory/72",
            )}
          >
            {lede}
          </p>
        )}
      </div>
      {aside && <div className="lg:pb-2 lg:text-right">{aside}</div>}
    </div>
  );
}
