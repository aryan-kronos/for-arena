import { alts, assets } from "@/data";
import { cn } from "@/utils/cn";

/**
 * Front of the pass = the approved ARANCH PASS visual, used exactly as supplied.
 * No provider name is ever printed on the physical pass; provider identity only
 * appears on the digital scan page.
 */
export function PassFrontArtwork({
  className,
  priority = false,
}: {
  className?: string;
  priority?: boolean;
}) {
  return (
    <img
      src={assets.passImage}
      alt={alts.passImage}
      className={cn("block h-full w-full bg-white object-contain", className)}
      loading={priority ? "eager" : "lazy"}
      decoding="async"
      draggable={false}
    />
  );
}

/** Reverse side: a plain ARANCH PASS back. Never shows customer information. */
export function PassBackArtwork({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 860 500"
      className={cn("block h-full w-full", className)}
      role="img"
      aria-label="Reverse of the ARANCH PASS, printed with the line every service stays connected."
      preserveAspectRatio="xMidYMid slice"
    >
      <rect width="860" height="500" fill="#2E0759" />
      <g stroke="rgba(247,240,216,0.10)" strokeWidth="1.5">
        {Array.from({ length: 10 }).map((_, i) => (
          <line key={i} x1={0} y1={i * 52 + 26} x2={860} y2={i * 52 + 26} />
        ))}
      </g>
      <g fill="none" stroke="#F4AD08" strokeWidth="2" opacity="0.75">
        <circle cx="430" cy="250" r="182" />
        <circle cx="430" cy="250" r="168" strokeDasharray="3 9" />
      </g>
      <text
        x="430"
        y="212"
        textAnchor="middle"
        fontFamily="Archivo Black, Arial Black, Arial, sans-serif"
        fontSize="50"
        fill="#F7F0D8"
      >
        EVERY SERVICE
      </text>
      <text
        x="430"
        y="268"
        textAnchor="middle"
        fontFamily="Archivo Black, Arial Black, Arial, sans-serif"
        fontSize="50"
        fill="#F4AD08"
      >
        STAYS
      </text>
      <text
        x="430"
        y="324"
        textAnchor="middle"
        fontFamily="Archivo Black, Arial Black, Arial, sans-serif"
        fontSize="50"
        fill="#F7F0D8"
      >
        CONNECTED.
      </text>
      <text x="44" y="468" fontFamily="IBM Plex Mono, monospace" fontSize="20" fill="rgba(247,240,216,0.6)">
        ARANCH PASS
      </text>
      <text
        x="816"
        y="468"
        textAnchor="end"
        fontFamily="IBM Plex Mono, monospace"
        fontSize="20"
        fill="rgba(247,240,216,0.6)"
      >
        AP-7K3M9 · 01/50
      </text>
    </svg>
  );
}
