import { useEffect, useRef } from "react";
import { PassBackArtwork, PassFrontArtwork } from "@/components/PassArtwork";
import { usePrefersReducedMotion } from "@/hooks/usePrefersReducedMotion";
import { cn } from "@/utils/cn";

type Props = {
  className?: string;
  /** thickness of the pass edge in px */
  depth?: number;
  priority?: boolean;
};

const REST_Y = -13;
const REST_X = 6;

/**
 * Interactive 3D ARANCH PASS.
 * - gentle automatic oscillation (never edge-on)
 * - cursor-follow tilt on desktop
 * - pointer / touch drag, eased return to rest, then autoplay resumes
 * - reduced motion: static angled view, no rAF loop
 */
export function InteractivePass({ className, depth = 9, priority = false }: Props) {
  const stageRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const reduced = usePrefersReducedMotion();

  useEffect(() => {
    const card = cardRef.current;
    const stage = stageRef.current;
    if (!card || !stage) return;

    if (reduced) {
      card.style.transform = `rotateX(${REST_X}deg) rotateY(${REST_Y}deg)`;
      return;
    }

    let raf = 0;
    let t = 0;
    let rotY = REST_Y;
    let rotX = REST_X;
    let dragging = false;
    let released = performance.now() - 5000;
    let hovering = false;
    let visible = true;
    let startX = 0;
    let startY = 0;
    let baseY = 0;
    let baseX = 0;
    let offY = 0;
    let offX = 0;
    let pointerId: number | null = null;

    const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));
    const apply = () => {
      card.style.transform = `rotateX(${rotX.toFixed(2)}deg) rotateY(${rotY.toFixed(2)}deg)`;
    };

    const tick = () => {
      raf = requestAnimationFrame(tick);
      if (!visible || dragging) return;
      t += 0.016;
      const settling = performance.now() - released < 1500;
      const targetY = settling || hovering ? REST_Y + offY : REST_Y + Math.sin(t * 0.5) * 15 + offY;
      const targetX = settling || hovering ? REST_X + offX : REST_X + Math.sin(t * 0.34) * 2.6 + offX;
      const ease = settling ? 0.05 : 0.085;
      rotY += (targetY - rotY) * ease;
      rotX += (targetX - rotX) * ease;
      apply();
    };
    raf = requestAnimationFrame(tick);

    const onPointerDown = (e: PointerEvent) => {
      if (e.button !== 0 && e.pointerType === "mouse") return;
      dragging = true;
      pointerId = e.pointerId;
      startX = e.clientX;
      startY = e.clientY;
      baseY = rotY;
      baseX = rotX;
      card.classList.add("is-dragging");
      try {
        card.setPointerCapture(e.pointerId);
      } catch {
        /* capture unsupported */
      }
    };

    const onPointerMove = (e: PointerEvent) => {
      if (dragging && e.pointerId === pointerId) {
        rotY = clamp(baseY + (e.clientX - startX) * 0.45, -165, 165);
        rotX = clamp(baseX - (e.clientY - startY) * 0.2, -32, 32);
        apply();
        if (e.cancelable) e.preventDefault();
      } else if (!dragging && hovering && e.pointerType === "mouse") {
        const r = stage.getBoundingClientRect();
        if (!r.width || !r.height) return;
        offY = clamp(((e.clientX - r.left) / r.width - 0.5) * 32, -28, 28);
        offX = clamp(-((e.clientY - r.top) / r.height - 0.5) * 13, -16, 16);
      }
    };

    const endDrag = (e?: PointerEvent) => {
      if (!dragging) return;
      dragging = false;
      released = performance.now();
      offY = 0;
      offX = 0;
      card.classList.remove("is-dragging");
      if (e && pointerId !== null) {
        try {
          card.releasePointerCapture(pointerId);
        } catch {
          /* already released */
        }
      }
      pointerId = null;
    };

    const onEnter = () => {
      hovering = true;
    };
    const onLeave = () => {
      hovering = false;
      offY = 0;
      offX = 0;
      released = performance.now();
    };
    const onDragStart = (e: Event) => e.preventDefault();

    const io =
      "IntersectionObserver" in window
        ? new IntersectionObserver(([entry]) => (visible = entry.isIntersecting), {
            threshold: 0,
          })
        : null;
    io?.observe(stage);

    card.addEventListener("pointerdown", onPointerDown);
    card.addEventListener("dragstart", onDragStart);
    window.addEventListener("pointermove", onPointerMove, { passive: false });
    window.addEventListener("pointerup", endDrag);
    window.addEventListener("pointercancel", endDrag);
    stage.addEventListener("pointerenter", onEnter);
    stage.addEventListener("pointerleave", onLeave);

    return () => {
      cancelAnimationFrame(raf);
      io?.disconnect();
      card.removeEventListener("pointerdown", onPointerDown);
      card.removeEventListener("dragstart", onDragStart);
      window.removeEventListener("pointermove", onPointerMove);
      window.removeEventListener("pointerup", endDrag);
      window.removeEventListener("pointercancel", endDrag);
      stage.removeEventListener("pointerenter", onEnter);
      stage.removeEventListener("pointerleave", onLeave);
    };
  }, [reduced]);

  return (
    <div ref={stageRef} className={cn("pass-stage select-none", className)}>
      <div
        ref={cardRef}
        className="pass-3d ticket-mask relative aspect-[43/25] w-full"
        style={{ transform: `rotateX(${REST_X}deg) rotateY(${REST_Y}deg)` }}
      >
        {/* edge slab so the object never becomes an infinitely thin line */}
        <div
          className="ticket-mask absolute inset-0 bg-[#cfc4a6]"
          style={{ transform: `translateZ(-${depth}px)` }}
          aria-hidden="true"
        />
        <div
          className="pass-face ticket-mask bg-white shadow-[0_36px_70px_-38px_rgba(46,7,89,0.6)]"
          style={{ transform: "translateZ(0.6px)" }}
        >
          <PassFrontArtwork priority={priority} />
        </div>
        <div
          className="pass-face ticket-mask bg-deepviolet"
          style={{ transform: `translateZ(-${depth}px) rotateY(180deg)` }}
        >
          <PassBackArtwork />
        </div>
      </div>
    </div>
  );
}
