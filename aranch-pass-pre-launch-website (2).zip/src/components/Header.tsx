import { useEffect, useRef, useState } from "react";
import { nav } from "@/data";
import { cn } from "@/utils/cn";

export function Wordmark({
  className,
  tone = "violet",
}: {
  className?: string;
  tone?: "ivory" | "violet";
}) {
  return (
    <span
      className={cn(
        "font-display text-[15px] whitespace-nowrap sm:text-[17px]",
        tone === "ivory" ? "text-ivory" : "text-deepviolet",
        className,
      )}
    >
      ARANCH<span className="text-saffron">·</span>PASS
    </span>
  );
}

export function Header() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const panelRef = useRef<HTMLDivElement>(null);
  const toggleRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 16);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (!open) return;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setOpen(false);
        toggleRef.current?.focus();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [open]);

  return (
    <header className="fixed inset-x-0 top-0 z-50">
      <div className="mx-auto w-full max-w-[1280px] px-3 pt-3 sm:px-6 sm:pt-4 lg:px-8">
        <div
          className={cn(
            "flex h-[60px] items-center justify-between gap-3 rounded-full border border-line bg-paper/92 px-3 backdrop-blur-xl transition-shadow duration-300 sm:px-4",
            scrolled
              ? "shadow-[0_16px_40px_-24px_rgba(46,7,89,0.55)]"
              : "shadow-[0_6px_20px_-18px_rgba(46,7,89,0.5)]",
          )}
        >
          <a
            href="#top"
            className="flex shrink-0 items-center gap-2.5 rounded-full py-2 pl-2 pr-3"
            aria-label="ARANCH PASS — back to top"
          >
            <span
              aria-hidden="true"
              className="grid h-8 w-8 place-items-center rounded-full bg-deepviolet"
            >
              <span className="h-2 w-2 rounded-full bg-saffron" />
            </span>
            <Wordmark />
          </a>

          <nav aria-label="Primary" className="hidden items-center gap-1 lg:flex">
            {nav.map((n) => (
              <a
                key={n.href}
                href={n.href}
                className="rounded-full px-4 py-2.5 text-[14px] font-medium text-ink/70 transition-colors hover:bg-violet/8 hover:text-deepviolet"
              >
                {n.label}
              </a>
            ))}
          </nav>

          <div className="flex shrink-0 items-center gap-2">
            <a
              href="#pilot"
              className="rounded-full bg-deepviolet px-4 py-3 text-[13px] font-semibold text-paper transition-colors hover:bg-violet sm:px-5 sm:text-[14px]"
            >
              Join the pilot
            </a>
            <button
              ref={toggleRef}
              type="button"
              onClick={() => setOpen((v) => !v)}
              aria-expanded={open}
              aria-controls="mobile-menu"
              aria-label={open ? "Close menu" : "Open menu"}
              className="grid h-11 w-11 place-items-center rounded-full bg-violet/8 text-deepviolet transition-colors hover:bg-violet/14 lg:hidden"
            >
              <svg width="18" height="14" viewBox="0 0 18 14" aria-hidden="true">
                {open ? (
                  <g stroke="currentColor" strokeWidth="1.9" strokeLinecap="round">
                    <line x1="3" y1="2" x2="15" y2="12" />
                    <line x1="15" y1="2" x2="3" y2="12" />
                  </g>
                ) : (
                  <g stroke="currentColor" strokeWidth="1.9" strokeLinecap="round">
                    <line x1="1" y1="2.5" x2="17" y2="2.5" />
                    <line x1="1" y1="7" x2="17" y2="7" />
                    <line x1="1" y1="11.5" x2="17" y2="11.5" />
                  </g>
                )}
              </svg>
            </button>
          </div>
        </div>

        <div
          id="mobile-menu"
          ref={panelRef}
          hidden={!open}
          className="mt-2 max-h-[calc(100dvh-96px)] overflow-y-auto rounded-[28px] border border-line bg-paper p-3 shadow-[0_30px_60px_-30px_rgba(46,7,89,0.5)] lg:hidden"
        >
          <nav aria-label="Mobile" className="grid gap-1">
            {nav.map((n, i) => (
              <a
                key={n.href}
                href={n.href}
                onClick={() => setOpen(false)}
                className="flex items-center justify-between rounded-[20px] bg-cream px-5 py-4 transition-colors hover:bg-violet/8"
              >
                <span className="text-[17px] font-bold text-deepviolet">{n.label}</span>
                <span className="mono text-[10px] text-violet/60">
                  {String(i + 1).padStart(2, "0")}
                </span>
              </a>
            ))}
          </nav>
          <p className="mono px-5 py-4 text-[11px] leading-relaxed tracking-[0.08em] text-muted uppercase">
            Pre-launch · concept and prototype stage
          </p>
        </div>
      </div>
    </header>
  );
}
