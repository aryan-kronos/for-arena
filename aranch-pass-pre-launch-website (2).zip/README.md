# ARANCH PASS — pre-launch site

**The service identity that stays with the asset.**
Core idea: _the service ends, the connection stays._ Attach → record → scan → rebook.

This is a pre-launch marketing site. It contains **no reviews, no user counts, no launch date, no
final pricing and no production photography claims**. Every demo UI is labelled `Demo · mock data`.

## Setup

```bash
npm install
npm run dev      # local development
npm run build    # production build → dist/index.html (single file)
npm run preview  # preview the production build
```

Stack: Vite + React 19 + TypeScript + Tailwind CSS v4 (single-file build via `vite-plugin-singlefile`).

## Component structure

```
src/
  App.tsx                          page composition (section order)
  data.ts                          ALL copy arrays, config, asset map, pricing flags
  index.css                        design tokens, notch/clip shapes, marquee, reveal, 3D pass
  hooks/
    usePrefersReducedMotion.ts
    useReveal.ts                   scroll reveal + scroll-progress helper
  components/
    Header.tsx                     sticky nav (solid plum surface) + mobile menu + Wordmark
    InteractivePass.tsx            3D pass (autoplay, hover tilt, drag, eased return)
    PassArtwork.tsx                coded vector pass front/back (+ photo swap)
    ui.tsx                         Container, Eyebrow, Button, SealRing, TraceLine,
                                   PhotoPlaceholder, Note
    sections/
      Opening.tsx     Hero · TraceBand · ProblemManifesto · TwoSides
      Product.tsx     PhysicalPass · ActivationRitual · PassBox · ActivationGrid
      System.tsx      SystemViews (technician / public scan / dashboard)
      Tables.tsx      PrivacyTable · CategoryRoadmap · ComparisonTable · ProviderSegments
      Closing.tsx     OfferArchitecture · MissionPrinciples · PrelaunchTransparency
      Conversion.tsx  FAQ · PilotForm · Footer
```

### Where to edit copy and pricing

Everything repeated lives in `src/data.ts`:

- `site` — brand strings, contact placeholder, WhatsApp href, **pricing flags**
  (`pricingLabel`, `pricingVisible`). Prices stay hidden until `pricingVisible` is `true`.
- `nav`, `bandItems`, `manifestoLines`, `ritualSteps`, `gridLegend`, `privacyRows`, `roadmap`,
  `compareRows`, `segments`, `offers`, `principles`, `transparency`, `faqs`, `footerLinks`.

## Visual language

Pinterest-style board aesthetic on the ARANCH PASS palette:

- warm paper / cream / white surfaces alternating with deep-violet and plum chapters;
- everything is a rounded **pin**: `--radius-pin: 26px`, soft two-layer shadow, lift on hover;
- a true CSS-column **masonry board** (`.board`) for the loop chapter;
- pill navigation, pill buttons, pill chips (`Chip`) for all status/meta labels;
- brand devices kept: passport seal rings, the dashed trace line, `01/50` issue numbering,
  the 50-cell activation grid and the ticket die-cut silhouette (`.ticket-mask`).

All hover, scale and marquee motion is disabled under `prefers-reduced-motion: reduce`.

## Asset map

Every image lives in `public/images/` and is imported through `src/assets/images.ts`, so the
single-file production build never depends on a separate asset request. Replace a file **in place,
keeping its filename**, and the whole site updates. Alt text sits beside the paths in
`src/data.ts → alts`.

| Key | File | Used at | Ratio |
|---|---|---|---|
| `passImage` | `aranch-pass-ticket.jpg` | hero 3D pass, object chapter, mission | 43:25 |
| `boxImage` | `aranch-pass-fifty-box.jpg` | box chapter | 5:4 |
| `activation` | `hero-pass-activation.jpg` | loop board, pilot form | 4:5 |
| `closeup` | `activation-closeup.jpg` | loop board, provider side | 3:2 |
| `returnScan` | `customer-return-scan.jpg` | loop board, customer side | 3:2 |
| `attached` | `board-attached-asset.jpg` | loop board, segments | 4:5 |
| `loopStill` | `board-service-loop.jpg` | loop board, box chapter, FAQ | 4:5 |
| `materialTest` | `real-material-test.jpg` | transparency chapter | 1:1 |
| `firstBatch` | `real-first-batch.jpg` | box chapter, transparency | 3:2 |

The pass and box visuals are approved concept directions; the supporting stills are studio
concept photography. Both are labelled as such on the page — none of them are presented as
evidence of a shipped batch or a completed pilot. The physical pass never carries a provider
name; provider identity appears only on the digital scan page.

**Rule:** the physical pass never carries a provider name. Provider identity appears only on the
digital scan page.

## Interactive pass

`InteractivePass` uses a ticket die-cut silhouette (`.notch`), a visible edge slab and
`transform-style: preserve-3d`. It oscillates gently on load, follows the cursor slightly on
desktop, accepts pointer/touch drag, eases back to rest on release and then resumes oscillation.
Native image drag and selection are disabled. With `prefers-reduced-motion: reduce` it renders as a
static angled view and all marquee/seal/trace animations stop.

## Forms

`PilotForm` is a two-stage form (contact first, optional business details second) with client-side
validation and an accessible error/success state. **There is no backend**: the success state says so
explicitly. The integration boundary is marked with a comment in `Conversion.tsx` — replace it with
a POST and record consent timestamp + source server-side, plus rate limiting and sanitisation.

## Honesty checklist implemented

- Pass and box are labelled **approved design directions / concept visuals**.
- No tamper-proof / waterproof claims — “planned for durable service use”.
- Activation timing labelled a workflow target, not measured performance.
- Activation grid states labelled illustrative demo states.
- Comparison table uses `Yes / Varies / No` with a category-level footnote.
- Roadmap categories marked *intended first pilot* vs *roadmap candidate*.
- No automatic WhatsApp reminder promise; no payment methods claimed; no launch date.
