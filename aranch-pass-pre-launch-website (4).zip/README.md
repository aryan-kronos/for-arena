# ARANCH PASS — pre-launch site

**The service identity that stays with the asset.**
Core idea: _the service ends, the connection stays._ Attach → record → scan → rebook.

This is a pre-launch marketing site. It contains **no reviews, no user counts, no launch date, no
final pricing and no production photography claims**. Every demo UI is labelled `Demo · mock data`.

## Setup

```bash
npm install
npm run dev      # local development
npm run build    # production build → dist/index.html (single file)
npm run preview  # preview the production build
```

Stack: Vite + React 19 + TypeScript + Tailwind CSS v4 (single-file build via `vite-plugin-singlefile`).

## Component structure

```
src/
  App.tsx                          page composition (section order)
  data.ts                          ALL copy arrays, config, asset map, pricing flags
  index.css                        design tokens, notch/clip shapes, marquee, reveal, 3D pass
  hooks/
    usePrefersReducedMotion.ts
    useReveal.ts                   scroll reveal + scroll-progress helper
  components/
    Header.tsx                     sticky nav (solid plum surface) + mobile menu + Wordmark
    InteractivePass.tsx            3D pass (autoplay, hover tilt, drag, eased return)
    PassArtwork.tsx                coded vector pass front/back (+ photo swap)
    ui.tsx                         Container, Eyebrow, Button, SealRing, TraceLine,
                                   PhotoPlaceholder, Note
    sections/
      Opening.tsx     Hero · TraceBand · ProblemManifesto · TwoSides
      Product.tsx     PhysicalPass · ActivationRitual · PassBox · ActivationGrid
      System.tsx      SystemViews (technician / public scan / dashboard)
      Tables.tsx      PrivacyTable · CategoryRoadmap · ComparisonTable · ProviderSegments
      Closing.tsx     OfferArchitecture · MissionPrinciples · PrelaunchTransparency
      Conversion.tsx  FAQ · PilotForm · Footer
```

### Where to edit copy and pricing

Everything repeated lives in `src/data.ts`:

- `site` — brand strings, contact placeholder, WhatsApp href, **pricing flags**
  (`pricingLabel`, `pricingVisible`). Prices stay hidden until `pricingVisible` is `true`.
- `nav`, `bandItems`, `manifestoLines`, `ritualSteps`, `gridLegend`, `privacyRows`, `roadmap`,
  `compareRows`, `segments`, `offers`, `principles`, `transparency`, `faqs`, `footerLinks`.

## Asset map

`src/data.ts → assets`. Drop the approved JPGs into `public/images/` and set the paths; the
components automatically switch from the coded vector artwork to the photograph.

| Slot | Path | Ratio | Status |
|---|---|---|---|
| Pass (approved) | `/images/aranch-pass-passport-seal.jpg` | 41:25 | set `assets.passImage` |
| 50-pass box (approved) | `/images/aranch-pass-fifty-box.jpg` | 16:9 | set `assets.boxImage` |
| Hero activation | `/images/hero-pass-activation.jpg` | 4:5 | not shot |
| Activation close-up | `/images/activation-closeup.jpg` | 3:2 | placeholder rendered |
| Customer return scan | `/images/customer-return-scan.jpg` | 3:2 | placeholder rendered |
| Material test | `/images/real-material-test.jpg` | 1:1 | placeholder rendered |
| First printed batch | `/images/real-first-batch.jpg` | 3:2 | placeholder rendered |

Until real photography exists, `PhotoPlaceholder` renders a designed seal-ring frame that prints
the exact future filename — no stock technicians, no pasted stickers on appliances.

**Rule:** the physical pass never carries a provider name. Provider identity appears only on the
digital scan page.

## Interactive pass

`InteractivePass` uses a ticket die-cut silhouette (`.notch`), a visible edge slab and
`transform-style: preserve-3d`. It oscillates gently on load, follows the cursor slightly on
desktop, accepts pointer/touch drag, eases back to rest on release and then resumes oscillation.
Native image drag and selection are disabled. With `prefers-reduced-motion: reduce` it renders as a
static angled view and all marquee/seal/trace animations stop.

## Forms

`PilotForm` is a two-stage form (contact first, optional business details second) with client-side
validation and an accessible error/success state. **There is no backend**: the success state says so
explicitly. The integration boundary is marked with a comment in `Conversion.tsx` — replace it with
a POST and record consent timestamp + source server-side, plus rate limiting and sanitisation.

## Honesty checklist implemented

- Pass and box are labelled **approved design directions / concept visuals**.
- No tamper-proof / waterproof claims — “planned for durable service use”.
- Activation timing labelled a workflow target, not measured performance.
- Activation grid states labelled illustrative demo states.
- Comparison table uses `Yes / Varies / No` with a category-level footnote.
- Roadmap categories marked *intended first pilot* vs *roadmap candidate*.
- No automatic WhatsApp reminder promise; no payment methods claimed; no launch date.
