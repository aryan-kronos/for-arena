import { useEffect, useState } from "react";
import { nav } from "@/data";
import { cn } from "@/utils/cn";

export function Wordmark({ className, tone = "ivory" }: { className?: string; tone?: "ivory" | "violet" }) {
  return (
    <span
      className={cn(
        "font-display text-[15px] tracking-[0.02em] whitespace-nowrap sm:text-[17px]",
        tone === "ivory" ? "text-ivory" : "text-deepviolet",
        className,
      )}
    >
      ARANCH<span className="text-saffron">·</span>PASS
    </span>
  );
}

export function Header() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <header className="fixed inset-x-0 top-0 z-50">
      <div
        className={cn(
          "bg-plum/95 border-b border-ivory/12 backdrop-blur-md transition-shadow duration-300",
          scrolled && "shadow-[0_10px_30px_-20px_rgba(0,0,0,0.9)]",
        )}
      >
        <div className="mx-auto flex h-[62px] w-full max-w-[1240px] items-center justify-between gap-4 px-5 sm:px-8 lg:px-12">
          <a href="#top" className="flex items-center gap-2.5" aria-label="ARANCH PASS — home">
            <span
              aria-hidden="true"
              className="grid h-7 w-7 place-items-center rounded-full border border-saffron/70"
            >
              <span className="h-2 w-2 rotate-45 bg-saffron" />
            </span>
            <Wordmark />
          </a>

          <nav aria-label="Primary" className="hidden items-center gap-7 lg:flex">
            {nav.map((n) => (
              <a
                key={n.href}
                href={n.href}
                className="mono text-[11px] tracking-[0.16em] text-ivory/70 uppercase transition-colors hover:text-saffron"
              >
                {n.label}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <a
              href="#pilot"
              className="clip-corner-sm bg-saffron px-4 py-2.5 text-[11px] font-semibold tracking-[0.1em] text-plum uppercase transition-colors hover:bg-[#ffbe22] sm:px-5"
            >
              Join the pilot
            </a>
            <button
              type="button"
              onClick={() => setOpen((v) => !v)}
              aria-expanded={open}
              aria-controls="mobile-menu"
              aria-label={open ? "Close menu" : "Open menu"}
              className="grid h-10 w-10 place-items-center border border-ivory/25 text-ivory lg:hidden"
            >
              <span className="sr-only">Menu</span>
              <svg width="18" height="14" viewBox="0 0 18 14" aria-hidden="true">
                {open ? (
                  <g stroke="currentColor" strokeWidth="1.8">
                    <line x1="2" y1="2" x2="16" y2="12" />
                    <line x1="16" y1="2" x2="2" y2="12" />
                  </g>
                ) : (
                  <g stroke="currentColor" strokeWidth="1.8">
                    <line x1="1" y1="2" x2="17" y2="2" />
                    <line x1="1" y1="7" x2="17" y2="7" />
                    <line x1="1" y1="12" x2="17" y2="12" />
                  </g>
                )}
              </svg>
            </button>
          </div>
        </div>
      </div>

      <div
        id="mobile-menu"
        hidden={!open}
        className="bg-plum text-ivory h-[calc(100dvh-62px)] overflow-y-auto border-b border-ivory/12 lg:hidden"
      >
        <nav aria-label="Mobile" className="flex flex-col px-5 py-4 sm:px-8">
          {nav.map((n, i) => (
            <a
              key={n.href}
              href={n.href}
              onClick={() => setOpen(false)}
              className="flex items-baseline gap-4 border-b border-ivory/10 py-5"
            >
              <span className="mono text-[10px] text-saffron">{String(i + 1).padStart(2, "0")}</span>
              <span className="font-display text-2xl">{n.label}</span>
            </a>
          ))}
          <p className="mono mt-6 text-[11px] leading-relaxed tracking-[0.08em] text-ivory/50 uppercase">
            Pre-launch · concept and prototype stage
          </p>
        </nav>
      </div>
    </header>
  );
}
