import { useCallback, useState } from "react";
import { PassObject, SceneShot } from "@/components/Scene";
import { ServiceSeal } from "@/components/PassArtwork";
import { Container, Eyebrow, Note, SealRing, TraceLine } from "@/components/ui";
import { gridLegend, ritualSteps, scenes, type GridState } from "@/data";
import { useReveal, useScrollProgress } from "@/hooks/useReveal";
import { cn } from "@/utils/cn";

/* ------------------------------------------------------------------ */
/* Chapter 03 — The physical pass                                      */
/* ------------------------------------------------------------------ */

const callouts = [
  {
    code: "01",
    label: "Unique QR",
    body: "One code per pass. Never reprinted, never shared between assets.",
  },
  {
    code: "02",
    label: "Human-readable asset code",
    body: "AP-7K3M9 — short enough to read out on a phone call.",
  },
  {
    code: "03",
    label: "Numbered issue",
    body: "01/50 keeps a physical box auditable against the software.",
  },
  {
    code: "04",
    label: "Durable identifier",
    body: "Planned for durable service use; material tests are still pending.",
  },
  {
    code: "05",
    label: "Safe public scan page",
    body: "Opens service information a stranger can safely see.",
  },
];

export function PhysicalPass() {
  const ref = useReveal<HTMLElement>();
  return (
    <section id="pass" ref={ref} className="relative overflow-hidden bg-ivory py-20 sm:py-28">
      <Container>
        <div className="reveal grid gap-6 lg:grid-cols-[1fr_auto] lg:items-end">
          <div className="max-w-[20ch]">
            <Eyebrow>Chapter 03 · The object</Eyebrow>
            <h2 className="font-display t-4 mt-5 text-deepviolet">
              A service record <span className="accent text-violet">with somewhere to live.</span>
            </h2>
          </div>
          <Note className="lg:text-right">
            Approved artwork, drawn to production spec. Not a photograph of a printed batch.
          </Note>
        </div>

        <div className="mt-14 grid gap-10 lg:grid-cols-[1.15fr_0.85fr] lg:gap-14">
          <div className="reveal relative">
            <div
              aria-hidden="true"
              className="absolute inset-0 m-auto aspect-square w-[76%] rounded-full bg-saffron/25"
            />
            <div className="relative mx-auto w-full max-w-[620px]">
              <PassObject tilt={-2} />
            </div>
            <div className="relative mt-7 flex flex-wrap justify-between gap-2">
              <span className="label text-violet/80">Front · 85 × 55 mm target</span>
              <span className="label text-violet/80">No provider name printed</span>
            </div>
          </div>

          <ul className="reveal self-center">
            {callouts.map((c) => (
              <li key={c.code} className="flex gap-5 border-t border-line py-5 last:border-b">
                <span className="label tnum shrink-0 pt-1 text-saffron">{c.code}</span>
                <div>
                  <h3 className="font-display text-[1.05rem] text-deepviolet">{c.label}</h3>
                  <p className="mt-1.5 text-[14px] leading-relaxed text-ink/70">{c.body}</p>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </Container>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Chapter 04 — The activation ritual                                  */
/* ------------------------------------------------------------------ */

function StepDiagram({ index, active }: { index: number; active: boolean }) {
  const stroke = active ? "#4D1688" : "rgba(77,22,136,0.55)";
  return (
    <svg viewBox="0 0 160 120" className="h-24 w-full" aria-hidden="true">
      <g stroke={stroke} strokeWidth="1.6" fill="none" strokeLinecap="round">
        {index === 0 && (
          <>
            <path d="M24 58 h94 v46 h-94 z" />
            <path d="M24 68 h94" opacity="0.4" />
            <g transform="rotate(-10 96 40)">
              <rect x="62" y="18" width="70" height="42" rx="7" fill="#F7F0D8" />
              <circle cx="114" cy="39" r="11" stroke="#F4AD08" />
            </g>
          </>
        )}
        {index === 1 && (
          <>
            <rect x="52" y="12" width="56" height="96" rx="10" />
            <rect x="66" y="32" width="28" height="28" rx="3" stroke="#F4AD08" />
            <path d="M66 78 h28 M66 88 h17" opacity="0.5" />
          </>
        )}
        {index === 2 && (
          <>
            <rect x="24" y="20" width="112" height="80" rx="6" />
            <path d="M38 42 h50 M38 58 h74 M38 74 h38" opacity="0.55" />
            <circle cx="116" cy="76" r="13" stroke="#F4AD08" />
            <path d="M110 76 l4.5 5 l9 -11" stroke="#F4AD08" />
          </>
        )}
        {index === 3 && (
          <>
            <rect x="32" y="12" width="96" height="96" rx="8" />
            <path d="M32 34 h96" opacity="0.4" />
            <rect x="58" y="56" width="48" height="30" rx="5" fill="#F4AD08" stroke="#4D1688" />
            <circle cx="82" cy="71" r="7" stroke="#2E0759" />
          </>
        )}
      </g>
    </svg>
  );
}

export function ActivationRitual() {
  const ref = useReveal<HTMLElement>();
  const [active, setActive] = useState(0);
  return (
    <section id="ritual" ref={ref} className="bg-paper py-20 sm:py-28">
      <Container>
        <div className="reveal grid gap-8 lg:grid-cols-[1.1fr_0.9fr] lg:items-end">
          <div>
            <Eyebrow>Chapter 04 · The activation ritual</Eyebrow>
            <h2 className="font-display t-4 mt-5 max-w-[17ch] text-deepviolet">
              Under a minute to give the service{" "}
              <span className="accent text-violet">a memory.</span>
            </h2>
          </div>
          <Note>
            Workflow target for the pilot; final timing will be tested with technicians. Nothing
            here has been measured in the field yet.
          </Note>
        </div>

        <div className="mt-12">
          <TraceLine className="h-8 w-full" />
        </div>

        <ol className="mt-4 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {ritualSteps.map((s, i) => (
            <li key={s.n}>
              <div
                onMouseEnter={() => setActive(i)}
                onFocus={() => setActive(i)}
                tabIndex={0}
                className={cn(
                  "reveal clip-corner hairline h-full bg-ivory/60 p-5 transition-colors duration-300 sm:p-6",
                  active === i && "border-violet/40 bg-ivory",
                )}
              >
                <div className="flex items-center justify-between">
                  <span className="label tnum text-violet">{s.n}</span>
                  <span
                    aria-hidden="true"
                    className={cn(
                      "h-2 w-2 rotate-45 transition-colors",
                      active === i ? "bg-saffron" : "bg-violet/25",
                    )}
                  />
                </div>
                <StepDiagram index={i} active={active === i} />
                <h3 className="font-display t-1 mt-4 text-deepviolet">{s.title}</h3>
                <p className="mt-2 text-[14px] leading-relaxed text-ink/70">{s.body}</p>
              </div>
            </li>
          ))}
        </ol>

        <div className="reveal mt-8">
          <SceneShot
            src={scenes.purifier.src}
            alt={scenes.purifier.alt}
            ratio="aspect-[16/9]"
            caption="Composite · step 04, the pass in its approved position"
            meta="Attach"
            placement={{ x: 50, y: 63, w: 19, rotate: -2, tiltY: -14, tiltX: 5 }}
          />
        </div>
      </Container>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Chapter 05 — The 50-pass box                                        */
/* ------------------------------------------------------------------ */

/**
 * The box is drawn, not photographed, so its panels carry the exact approved
 * typography and the same seal artwork as the pass itself.
 */
function BoxArtwork({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 760 560"
      className={className}
      role="img"
      aria-label="Concept rendering of the ARANCH PASS box: an open cream, purple and saffron carton holding a stack of fifty numbered service passes, with the line every service stays connected printed inside the lid."
    >
      <defs>
        <linearGradient id="apBoxLid" x1="0" y1="0" x2="0.3" y2="1">
          <stop offset="0%" stopColor="#FFFDF7" />
          <stop offset="100%" stopColor="#EFE9D7" />
        </linearGradient>
        <linearGradient id="apBoxFront" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#F8F3E3" />
          <stop offset="100%" stopColor="#E8E1CC" />
        </linearGradient>
        <linearGradient id="apBoxSide" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#4D1688" />
          <stop offset="100%" stopColor="#2E0759" />
        </linearGradient>
      </defs>

      {/* ground shadow */}
      <ellipse cx="380" cy="512" rx="250" ry="24" fill="rgba(46,7,89,0.16)" />

      {/* lid, tilted back */}
      <g>
        <path d="M196 66 L604 34 L676 92 L262 130 Z" fill="url(#apBoxLid)" stroke="#D9D2BC" strokeWidth="1.5" />
        <path d="M196 66 L604 34 L604 20 L196 52 Z" fill="#4D1688" />
        <path d="M604 34 L676 92 L676 76 L604 20 Z" fill="#F4AD08" />
        <g transform="translate(436 84) rotate(-4.6)">
          <text
            textAnchor="middle"
            fill="#4D1688"
            style={{ fontFamily: "var(--font-display)", fontWeight: 700 }}
          >
            <tspan x="0" y="-8" fontSize="25">
              EVERY SERVICE
            </tspan>
            <tspan x="0" y="20" fontSize="25">
              STAYS CONNECTED.
            </tspan>
          </text>
          <g stroke="#F4AD08" strokeWidth="2.4" strokeLinecap="round">
            <line x1="-52" y1="34" x2="-14" y2="34" />
            <line x1="14" y1="34" x2="52" y2="34" />
          </g>
          <rect x="-5" y="29" width="10" height="10" fill="#F4AD08" transform="rotate(45 0 34)" />
        </g>
      </g>

      {/* pass stack inside */}
      <g>
        {[6, 5, 4, 3, 2, 1, 0].map((i) => (
          <path
            key={i}
            d={`M232 ${248 - i * 7} L512 ${218 - i * 7} L566 ${252 - i * 7} L286 ${284 - i * 7} Z`}
            fill={i === 0 ? "#F4F0E0" : i % 2 ? "#E9E3CF" : "#EFEADA"}
            stroke="rgba(46,7,89,0.22)"
            strokeWidth="1.2"
          />
        ))}
        {/* top pass: same monogram + seal as the real artwork */}
        <g transform="translate(232 190) skewY(-6.2)">
          <text
            x="34"
            y="66"
            fontSize="62"
            fill="#F5A81C"
            style={{ fontFamily: "var(--font-display)", fontWeight: 900, fontStyle: "italic" }}
          >
            AP
          </text>
          <text
            x="30"
            y="62"
            fontSize="62"
            fill="#3E1263"
            style={{ fontFamily: "var(--font-display)", fontWeight: 900, fontStyle: "italic" }}
          >
            AP
          </text>
          <g transform="translate(190 6) scale(0.155)">
            <ServiceSeal />
          </g>
        </g>
      </g>

      {/* box body */}
      <g>
        <path d="M162 268 L512 232 L512 404 L162 448 Z" fill="url(#apBoxFront)" stroke="#D9D2BC" strokeWidth="1.5" />
        <path d="M512 232 L644 292 L644 452 L512 404 Z" fill="url(#apBoxSide)" />
        <path d="M162 268 L512 232 L644 292 L286 330 Z" fill="#FBF7EA" stroke="#D9D2BC" strokeWidth="1.5" />

        {/* front face artwork */}
        <g transform="translate(196 300) skewY(-6.2)">
          <text
            x="0"
            y="42"
            fontSize="42"
            fill="#3E1263"
            letterSpacing="1"
            style={{ fontFamily: "var(--font-display)", fontWeight: 700 }}
          >
            ARANCH
          </text>
          <text
            x="0"
            y="82"
            fontSize="42"
            fill="#3E1263"
            letterSpacing="1"
            style={{ fontFamily: "var(--font-display)", fontWeight: 700 }}
          >
            PASS
          </text>
          <g stroke="#F4AD08" strokeWidth="2.6" strokeLinecap="round">
            <line x1="0" y1="98" x2="46" y2="98" />
            <line x1="60" y1="98" x2="106" y2="98" />
          </g>
        </g>

        {/* saffron count panel */}
        <path d="M392 250 L470 242 L470 418 L392 428 Z" fill="#F4AD08" />
        <g transform="translate(404 306) skewY(-6.2)">
          <text
            x="0"
            y="0"
            fontSize="52"
            fill="#3E1263"
            style={{ fontFamily: "var(--font-display)", fontWeight: 800 }}
          >
            50
          </text>
          <text x="0" y="26" fontSize="15" fill="#3E1263" style={{ fontFamily: "var(--font-body)", fontWeight: 700 }}>
            SERVICE
          </text>
          <text x="0" y="46" fontSize="15" fill="#3E1263" style={{ fontFamily: "var(--font-body)", fontWeight: 700 }}>
            PASSES
          </text>
        </g>

        {/* side panel type */}
        <g transform="translate(544 330) skewY(24)">
          <text
            x="0"
            y="0"
            fontSize="26"
            fill="#F4AD08"
            style={{ fontFamily: "var(--font-display)", fontWeight: 700 }}
          >
            ARANCH PASS
          </text>
        </g>

        {/* base rule */}
        <path d="M162 430 L512 388 L512 404 L162 448 Z" fill="#F4AD08" opacity="0.9" />
      </g>
    </svg>
  );
}

const boxCodes = ["AP-7K3M9", "AP-2R8QD", "AP-9V4XL", "AP-5B1TC", "AP-3H6NZ", "AP-8M2WK"];

export function PassBox() {
  const ref = useReveal<HTMLElement>();
  return (
    <section ref={ref} className="relative overflow-hidden bg-deepviolet py-20 text-ivory sm:py-28">
      <SealRing
        className="pointer-events-none absolute -bottom-40 -left-32 w-[460px] opacity-20"
        tone="ivory"
        text="FIFTY PASSES · ONE BOX · "
      />
      <Container className="relative">
        <div className="grid gap-12 lg:grid-cols-[0.95fr_1.05fr] lg:items-center lg:gap-16">
          <div className="reveal">
            <Eyebrow tone="dark">Chapter 05 · The box</Eyebrow>
            <h2 className="font-display t-4 mt-5 max-w-[17ch]">
              Fifty completed jobs,{" "}
              <span className="accent text-saffron">ready to stay connected.</span>
            </h2>
            <p className="mt-6 max-w-[46ch] leading-relaxed text-ivory/75">
              Each box contains a numbered set of unique service passes. Every QR and asset code is
              issued individually; the provider activates them as work is completed.
            </p>

            <div className="mt-8 flex items-center gap-5">
              <span className="font-display tnum t-5 text-saffron">01</span>
              <span className="h-12 w-px bg-ivory/25" />
              <span className="label text-ivory/60">/ 50 issued</span>
            </div>

            <ul className="mt-8 flex flex-wrap gap-2">
              {boxCodes.map((c) => (
                <li key={c} className="label clip-corner-sm hairline-dark px-3 py-1.5 text-ivory/70">
                  {c}
                </li>
              ))}
              <li className="label px-3 py-1.5 text-ivory/40">+ 44 more</li>
            </ul>

            <div className="hairline-dark mt-10 p-4">
              <Note tone="dark">
                Packaging concept shown as a drawn rendering. Final material, dimensions and print
                production are still being tested.
              </Note>
            </div>
          </div>

          <div className="reveal">
            <div className="clip-corner bg-paper p-4 sm:p-8">
              <BoxArtwork className="block h-auto w-full" />
            </div>
            <p className="label mt-3 text-ivory/45">Concept rendering · drawn to the approved spec</p>
          </div>
        </div>
      </Container>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Chapter 06 — Activation grid                                        */
/* ------------------------------------------------------------------ */

const stateStyles: Record<GridState, string> = {
  issued: "border-line bg-transparent text-muted",
  activated: "border-violet bg-violet text-ivory",
  due: "border-saffron bg-saffron text-plum",
  rebooked: "border-deepviolet bg-paper text-deepviolet",
};

function stateFor(i: number, p: number): GridState {
  const reach = p * 62 - 4;
  if (i > reach) return "issued";
  if (i > reach - 10) return "activated";
  if (i % 7 === 3) return "due";
  if (i % 5 === 0) return "rebooked";
  return "activated";
}

export function ActivationGrid() {
  const [p, setP] = useState(0);
  const onProgress = useCallback((v: number) => setP(v), []);
  const ref = useScrollProgress<HTMLElement>(onProgress);
  const cells = Array.from({ length: 50 }, (_, i) => i + 1);
  const narrative = [
    { code: "01/50", label: "issued" },
    { code: "12/50", label: "activated" },
    { code: "31/50", label: "due soon" },
    { code: "50/50", label: "ready for the next box" },
  ];

  return (
    <section ref={ref} className="bg-paper py-20 sm:py-28">
      <Container>
        <div className="grid gap-8 lg:grid-cols-[0.9fr_1.1fr] lg:gap-16">
          <div>
            <Eyebrow>Chapter 06 · Activation grid</Eyebrow>
            <h2 className="font-display t-4 mt-5 max-w-[16ch] text-deepviolet">
              Physical passes, <span className="accent text-violet">tracked as software states.</span>
            </h2>
            <p className="mt-5 max-w-[44ch] leading-relaxed text-ink/75">
              Every pass in a box has a state. As jobs are completed the box empties and the
              dashboard fills — the same fifty identifiers, seen from two sides.
            </p>

            <ul className="mt-8 grid gap-3">
              {gridLegend.map((l) => (
                <li key={l.state} className="flex items-start gap-3">
                  <span
                    aria-hidden="true"
                    className={cn("mt-1.5 h-3.5 w-3.5 shrink-0 border", stateStyles[l.state])}
                  />
                  <span className="text-[14px] text-ink/80">
                    <span className="font-semibold text-deepviolet">{l.label}</span>
                    <span className="text-muted"> — {l.hint}</span>
                  </span>
                </li>
              ))}
            </ul>

            <Note className="mt-8">
              Illustrative demo states. These are not real customer records and no live data is
              shown anywhere on this page.
            </Note>
          </div>

          <div>
            <div className="clip-corner hairline bg-ivory p-4 sm:p-7">
              <div className="flex items-center justify-between">
                <span className="label text-violet">Box A · 50 passes</span>
                <span className="label text-muted">Demo</span>
              </div>
              <div className="mt-4 grid grid-cols-5 gap-2 sm:grid-cols-10 sm:gap-2.5">
                {cells.map((n) => {
                  const st = stateFor(n, p);
                  return (
                    <div
                      key={n}
                      title={`${String(n).padStart(2, "0")}/50 · ${st}`}
                      className={cn(
                        "mono tnum clip-corner-sm flex aspect-[5/3] items-center justify-center border text-[9px] transition-colors duration-500",
                        stateStyles[st],
                      )}
                    >
                      {String(n).padStart(2, "0")}
                    </div>
                  );
                })}
              </div>
            </div>

            <ul className="mt-5 grid gap-2 sm:grid-cols-2">
              {narrative.map((n) => (
                <li
                  key={n.code}
                  className="hairline flex items-center justify-between px-3 py-2.5"
                >
                  <span className="label tnum text-violet">{n.code}</span>
                  <span className="label text-muted">{n.label}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </Container>
    </section>
  );
}
