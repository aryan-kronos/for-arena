import { Container, Eyebrow, Note, SealRing } from "@/components/ui";
import { compareColumns, compareRows, privacyRows, roadmap, segments, type CompareValue } from "@/data";
import { useReveal } from "@/hooks/useReveal";
import { cn } from "@/utils/cn";

/* Section 10 — Public vs private ---------------------------------- */

export function PrivacyTable() {
  const ref = useReveal<HTMLElement>();
  return (
    <section id="privacy" ref={ref} className="bg-plum py-20 text-ivory sm:py-28">
      <Container>
        <div className="reveal grid gap-6 lg:grid-cols-[1fr_auto] lg:items-end">
          <div className="max-w-[18ch]">
            <Eyebrow tone="dark">Chapter 08 · Data boundaries</Eyebrow>
            <h2 className="font-display t-4 mt-5">
              Useful in public.
              <br />
              <span className="accent text-saffron">Protected by default.</span>
            </h2>
          </div>
          <Note tone="dark" className="lg:text-right">
            The architecture is privacy-led by design and remains subject to a production security
            review. We do not claim it is “100% secure”.
          </Note>
        </div>

        <div className="reveal mt-12 grid gap-px overflow-hidden border border-ivory/20 md:grid-cols-2">
          <div className="bg-ivory/5">
            <h3 className="mono border-b border-ivory/20 px-5 py-4 text-[11px] tracking-[0.2em] text-saffron uppercase">
              Public after scan
            </h3>
            <ul>
              {privacyRows.map((r) => (
                <li
                  key={r.public}
                  className="flex items-center gap-3 border-b border-ivory/12 px-5 py-4 text-[15px] last:border-b-0"
                >
                  <span aria-hidden="true" className="text-saffron">
                    ✓
                  </span>
                  {r.public}
                </li>
              ))}
            </ul>
          </div>
          <div className="bg-deepviolet/60 md:border-l md:border-ivory/20">
            <h3 className="mono border-b border-ivory/20 px-5 py-4 text-[11px] tracking-[0.2em] text-ivory/70 uppercase">
              Private / verified only
            </h3>
            <ul>
              {privacyRows.map((r) => (
                <li
                  key={r.private}
                  className="flex items-center gap-3 border-b border-ivory/12 px-5 py-4 text-[15px] text-ivory/75 last:border-b-0"
                >
                  <span
                    aria-hidden="true"
                    className="grid h-4 w-4 shrink-0 place-items-center rounded-full border border-ivory/40 text-[9px]"
                  >
                    ×
                  </span>
                  {r.private}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </Container>
    </section>
  );
}

/* Section 11 — Category roadmap ----------------------------------- */

function CategoryGlyph({ i }: { i: number }) {
  return (
    <svg viewBox="0 0 120 100" className="h-20 w-full" aria-hidden="true">
      <g fill="none" stroke="#4D1688" strokeWidth="1.6">
        {i === 0 && (
          <>
            <rect x="34" y="12" width="52" height="76" rx="8" />
            <rect x="44" y="24" width="32" height="22" rx="3" stroke="#F4AD08" />
            <path d="M44 60 h32 M44 70 h20" opacity="0.5" />
          </>
        )}
        {i === 1 && (
          <>
            <rect x="18" y="26" width="84" height="34" rx="6" />
            <path d="M26 68 q10 12 20 0 M52 68 q10 12 20 0 M78 68 q10 12 16 0" stroke="#F4AD08" />
            <path d="M26 42 h68" opacity="0.5" />
          </>
        )}
        {i === 2 && (
          <>
            <circle cx="32" cy="70" r="16" />
            <circle cx="90" cy="70" r="16" />
            <path d="M32 70 l18 -26 h26 l14 26" stroke="#F4AD08" />
            <path d="M50 44 h22" />
          </>
        )}
      </g>
    </svg>
  );
}

export function CategoryRoadmap() {
  const ref = useReveal<HTMLElement>();
  return (
    <section id="roadmap" ref={ref} className="bg-paper py-20 sm:py-28">
      <Container>
        <div className="reveal max-w-[24ch]">
          <Eyebrow>Chapter 09 · Roadmap</Eyebrow>
          <h2 className="font-display t-4 mt-5 text-deepviolet">
            Start with one service.{" "}
            <span className="accent text-violet">Build for every maintained asset.</span>
          </h2>
        </div>

        <div className="mt-12 grid gap-5 md:grid-cols-3">
          {roadmap.map((c, i) => (
            <article
              key={c.code}
              className={cn(
                "reveal clip-corner p-6 sm:p-7",
                c.tone === "first" ? "bg-ivory hairline" : "hairline bg-transparent",
              )}
            >
              <div className="mono flex items-center justify-between text-[10px] tracking-[0.16em] uppercase">
                <span className="text-violet">{c.code}</span>
                <span
                  className={cn(
                    "clip-corner-sm px-2 py-1",
                    c.tone === "first" ? "bg-saffron text-plum" : "border border-line text-muted",
                  )}
                >
                  {c.status}
                </span>
              </div>
              <CategoryGlyph i={i} />
              <h3 className="font-display mt-4 text-[1.45rem] text-deepviolet">{c.title}</h3>
              <p className="mt-2.5 text-[14px] leading-relaxed text-ink/70">{c.body}</p>
            </article>
          ))}
        </div>
        <Note className="mt-6">
          Only one category is intended for the first pilot. Nothing on this page should be read as
          all three being operational.
        </Note>
      </Container>
    </section>
  );
}

/* Section 12 — Comparison ----------------------------------------- */

function Mark({ v }: { v: CompareValue }) {
  const map = {
    yes: { t: "Yes", c: "bg-saffron text-plum" },
    varies: { t: "Varies", c: "border border-line text-muted" },
    no: { t: "No", c: "border border-line text-muted/70" },
  }[v];
  return (
    <span
      className={cn(
        "mono clip-corner-sm inline-block min-w-[58px] px-2 py-1.5 text-center text-[10px] tracking-[0.1em] uppercase",
        map.c,
      )}
    >
      {map.t}
    </span>
  );
}

export function ComparisonTable() {
  const ref = useReveal<HTMLElement>();
  return (
    <section ref={ref} className="bg-ivory py-20 sm:py-28">
      <Container>
        <div className="reveal max-w-[22ch]">
          <Eyebrow>Chapter 10 · Positioning</Eyebrow>
          <h2 className="font-display t-4 mt-5 text-deepviolet">
            More useful than a static sticker.{" "}
            <span className="accent text-violet">Lighter than a full CRM.</span>
          </h2>
        </div>

        <div className="reveal scroll-x mt-12 -mx-5 px-5 sm:mx-0 sm:px-0">
          <table className="w-full min-w-[720px] border-collapse text-left">
            <caption className="sr-only">
              Comparison of notebook or WhatsApp, static number stickers, field-service CRMs and
              ARANCH PASS
            </caption>
            <thead>
              <tr>
                <th scope="col" className="w-[34%] border-b border-line py-4 pr-4 align-bottom">
                  <span className="mono text-[10px] tracking-[0.16em] text-muted uppercase">
                    Capability
                  </span>
                </th>
                {compareColumns.map((c, i) => (
                  <th
                    key={c}
                    scope="col"
                    className={cn(
                      "border-b border-line px-3 py-4 align-bottom",
                      i === compareColumns.length - 1 && "bg-paper",
                    )}
                  >
                    <span
                      className={cn(
                        "font-display block text-[13px] leading-tight",
                        i === compareColumns.length - 1 ? "text-deepviolet" : "text-muted",
                      )}
                    >
                      {c}
                    </span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {compareRows.map((r) => (
                <tr key={r.label}>
                  <th
                    scope="row"
                    className="border-b border-line py-4 pr-4 text-[14px] font-medium text-ink/85"
                  >
                    {r.label}
                  </th>
                  {r.values.map((v, i) => (
                    <td
                      key={i}
                      className={cn(
                        "border-b border-line px-3 py-4",
                        i === r.values.length - 1 && "bg-paper",
                      )}
                    >
                      <Mark v={v} />
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <Note className="mt-5">
          Category-level positioning; individual products vary. Marks describe typical behaviour of
          a category, not any specific vendor.
        </Note>
      </Container>
    </section>
  );
}

/* Section 13 — Provider segments ---------------------------------- */

export function ProviderSegments() {
  const ref = useReveal<HTMLElement>();
  return (
    <section id="providers" ref={ref} className="relative overflow-hidden bg-deepviolet py-20 text-ivory sm:py-28">
      <SealRing
        className="pointer-events-none absolute -top-32 -left-28 w-[380px] opacity-15"
        tone="ivory"
        text="FOR SERVICE BUSINESSES · "
      />
      <Container className="relative">
        <div className="reveal max-w-[20ch]">
          <Eyebrow tone="dark">Chapter 11 · Who it is for</Eyebrow>
          <h2 className="font-display t-4 mt-5">
            Built around how service work <span className="accent text-saffron">actually ends.</span>
          </h2>
        </div>

        <div className="mt-12 grid gap-px border border-ivory/18 sm:grid-cols-2 lg:grid-cols-3">
          {segments.map((s) => (
            <article
              key={s.code}
              className="reveal group border-b border-ivory/15 p-6 transition-colors duration-300 hover:bg-ivory/6 sm:p-8 lg:border-r"
            >
              <div className="flex items-center justify-between">
                <span className="mono text-[10px] tracking-[0.18em] text-saffron">{s.code}</span>
                <span
                  aria-hidden="true"
                  className="h-2 w-2 rotate-45 bg-ivory/30 transition-colors group-hover:bg-saffron"
                />
              </div>
              <h3 className="font-display mt-6 text-[1.35rem]">{s.title}</h3>
              <p className="mt-3 text-[14px] leading-relaxed text-ivory/70">{s.body}</p>
            </article>
          ))}
        </div>
      </Container>
    </section>
  );
}
