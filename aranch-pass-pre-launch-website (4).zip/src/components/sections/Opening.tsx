import { InteractivePass } from "@/components/InteractivePass";
import { SceneShot } from "@/components/Scene";
import { Button, Container, Eyebrow, Note, SealRing, TraceLine } from "@/components/ui";
import { bandItems, manifestoLines, scenes } from "@/data";
import { useReveal } from "@/hooks/useReveal";

export function Hero() {
  const ref = useReveal<HTMLElement>();
  return (
    <section
      id="top"
      ref={ref}
      className="relative overflow-hidden bg-paper pt-[104px] pb-16 sm:pt-[132px] sm:pb-24"
    >
      <div aria-hidden="true" className="pointer-events-none absolute inset-0">
        <div className="mx-auto h-full w-full max-w-[1240px] px-5 sm:px-8 lg:px-12">
          <div className="grid h-full grid-cols-4 lg:grid-cols-12">
            {Array.from({ length: 12 }).map((_, i) => (
              <div key={i} className={`border-l border-line/40 ${i > 3 ? "hidden lg:block" : ""}`} />
            ))}
          </div>
        </div>
      </div>

      <Container className="relative">
        <div className="grid items-center gap-12 lg:grid-cols-[1.03fr_0.97fr] lg:gap-10">
          <div className="reveal">
            <Eyebrow>Physical service identity · built for India</Eyebrow>

            <h1 className="font-display t-6 mt-7 text-deepviolet">
              Every service
              <br />
              should leave
              <br />
              <span className="accent relative inline-block text-violet">
                a way back.
                <svg
                  aria-hidden="true"
                  viewBox="0 0 320 12"
                  preserveAspectRatio="none"
                  className="absolute -bottom-2 left-0 h-[9px] w-full"
                >
                  <path
                    d="M2 8 C 80 2, 240 2, 318 8"
                    stroke="#F4AD08"
                    strokeWidth="5"
                    fill="none"
                    strokeLinecap="round"
                  />
                </svg>
              </span>
            </h1>

            <p className="lede mt-9 max-w-[50ch] text-ink/75">
              ARANCH PASS gives every serviced asset a unique physical identity — so technicians
              can record the job, and customers can find the original provider again.
            </p>

            <div className="mt-9 flex flex-wrap items-center gap-3">
              <Button href="#pilot">Join the pilot</Button>
              <Button href="#system" variant="ghost">
                See the system →
              </Button>
            </div>

            <div className="mt-11 max-w-[520px]">
              <TraceLine className="h-8 w-full" />
              <p className="label mt-3 text-muted">
                Pre-launch · First pilots being designed · No customer app required
              </p>
            </div>
          </div>

          <div className="reveal relative">
            <div
              aria-hidden="true"
              className="absolute top-1/2 left-1/2 aspect-square w-[84%] -translate-x-1/2 -translate-y-1/2 rounded-full bg-saffron"
            />
            <SealRing
              className="pointer-events-none absolute top-1/2 left-1/2 aspect-square w-[104%] -translate-x-1/2 -translate-y-1/2 opacity-70"
              tone="violet"
            />
            <div className="relative px-2 py-10 sm:px-8">
              <InteractivePass className="mx-auto w-full max-w-[470px]" />
            </div>
            <div className="relative mt-1 flex flex-wrap justify-between gap-2">
              <span className="label text-violet/70">Approved design · vector artwork</span>
              <span className="label tnum text-violet/70">AP-7K3M9 · 01/50</span>
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}

export function TraceBand() {
  const row = [...bandItems, ...bandItems, ...bandItems, ...bandItems];
  return (
    <section aria-label="The ARANCH PASS service loop" className="bg-deepviolet py-5 sm:py-6">
      <div className="overflow-hidden">
        <div className="marquee-track items-center gap-8 px-4">
          {row.map((item, i) => (
            <span key={i} className="flex shrink-0 items-center gap-8">
              <span className="font-display t-2 text-ivory whitespace-nowrap">{item}</span>
              <span aria-hidden="true" className="flex items-center gap-2">
                <span className="h-[6px] w-[6px] rotate-45 bg-saffron" />
                <span className="label tnum text-ivory/40">
                  {String((i % 50) + 1).padStart(2, "0")}/50
                </span>
              </span>
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}

export function ProblemManifesto() {
  const ref = useReveal<HTMLElement>();
  return (
    <section ref={ref} className="relative overflow-hidden bg-plum py-20 text-ivory sm:py-28">
      <SealRing
        className="pointer-events-none absolute -top-24 -right-24 w-[420px] opacity-15"
        tone="ivory"
        text="LOST CONTACT · LOST HISTORY · "
      />
      <Container className="relative">
        <div className="reveal">
          <Eyebrow tone="dark">Chapter 01 · The problem</Eyebrow>
        </div>

        <h2 className="reveal font-display t-5 mt-7 max-w-[17ch]">
          The job gets completed.
          <br />
          <span className="accent text-ivory/45">The connection gets lost.</span>
        </h2>

        <ol className="mt-14 border-t border-ivory/15 sm:mt-16">
          {manifestoLines.map((line, i) => (
            <li
              key={line}
              className="reveal flex items-baseline gap-5 border-b border-ivory/15 py-6 sm:gap-10 sm:py-8"
            >
              <span className="label tnum shrink-0 text-saffron">
                {String(i + 1).padStart(2, "0")}
              </span>
              <span className="t-3 leading-[1.25] text-ivory/90">{line}</span>
            </li>
          ))}
        </ol>

        <div className="reveal mt-14 grid gap-8 lg:grid-cols-[1.1fr_0.9fr] lg:items-end">
          <p className="font-display t-3 text-saffron">
            ARANCH PASS keeps a way back <span className="accent">attached to the asset itself.</span>
          </p>
          <Note tone="dark">
            No statistics are shown in this section on purpose. We have not run a field study yet,
            and we will not publish numbers we cannot source.
          </Note>
        </div>
      </Container>
    </section>
  );
}

export function TwoSides() {
  const ref = useReveal<HTMLElement>();
  return (
    <section ref={ref} className="bg-paper py-20 sm:py-28">
      <Container>
        <div className="reveal max-w-[44ch]">
          <Eyebrow>Chapter 02 · Two sides, one pass</Eyebrow>
          <h2 className="font-display t-4 mt-5 text-deepviolet">
            The same pass does <span className="accent text-violet">two different jobs.</span>
          </h2>
        </div>

        <div className="mt-12 grid gap-6 lg:grid-cols-2 lg:gap-8">
          <article className="reveal clip-corner hairline flex flex-col bg-ivory p-6 sm:p-9">
            <span className="label text-violet">Side A · Provider</span>
            <h3 className="font-display t-3 mt-5 text-deepviolet">
              The technician finishes the job.
            </h3>
            <p className="mt-4 max-w-[42ch] leading-relaxed text-ink/75">
              Scan the pass, record the service and set the next recommended date. The asset is now
              connected to the provider’s system.
            </p>
            <SceneShot
              className="mt-8"
              src={scenes.technicianHands.src}
              alt={scenes.technicianHands.alt}
              ratio="aspect-[3/2]"
              caption="Composite · pass artwork on a real service scene"
              meta="Record"
              placement={{ x: 74, y: 74, w: 40, rotate: -7, tiltY: 22, tiltX: 6 }}
            />
          </article>

          <article className="reveal clip-corner flex flex-col bg-deepviolet p-6 text-ivory sm:p-9">
            <span className="label text-saffron">Side B · Customer</span>
            <h3 className="font-display t-3 mt-5">The customer needs help again.</h3>
            <p className="mt-4 max-w-[42ch] leading-relaxed text-ivory/75">
              Scan the same pass, see safe service information and contact the original provider
              without searching from zero.
            </p>
            <SceneShot
              className="mt-8"
              tone="dark"
              src={scenes.purifier.src}
              alt={scenes.purifier.alt}
              ratio="aspect-[3/2]"
              caption="Composite · pass artwork on a real kitchen scene"
              meta="Rebook"
              placement={{ x: 52, y: 66, w: 30, rotate: -3, tiltY: -16, tiltX: 4 }}
            />
          </article>
        </div>
      </Container>
    </section>
  );
}
