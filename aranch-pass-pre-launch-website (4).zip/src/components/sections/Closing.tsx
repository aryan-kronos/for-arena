import { PassObject, SceneShot } from "@/components/Scene";
import { Button, Container, Eyebrow, Note, PlannedShot, SealRing } from "@/components/ui";
import { offers, photographyBrief, principles, scenes, site, transparency } from "@/data";
import { useReveal } from "@/hooks/useReveal";
import { cn } from "@/utils/cn";

/* Section 14 — Offer architecture --------------------------------- */

export function OfferArchitecture() {
  const ref = useReveal<HTMLElement>();
  return (
    <section ref={ref} className="bg-paper py-20 sm:py-28">
      <Container>
        <div className="reveal grid gap-6 lg:grid-cols-[1fr_auto] lg:items-end">
          <div className="max-w-[20ch]">
            <Eyebrow>Chapter 12 · Offer architecture</Eyebrow>
            <h2 className="font-display t-4 mt-5 text-deepviolet">
              Three ways this <span className="accent text-violet">may be bought.</span>
            </h2>
          </div>
          <Note className="lg:text-right">
            {site.pricingLabel}. No figures are published yet — they would be invented.
          </Note>
        </div>

        <div className="mt-12 grid gap-5 lg:grid-cols-3">
          {offers.map((o) => (
            <article
              key={o.code}
              className={cn(
                "reveal clip-corner flex flex-col p-6 sm:p-8",
                o.featured ? "bg-deepviolet text-ivory" : "hairline bg-ivory",
              )}
            >
              <div className="mono flex items-center justify-between text-[10px] tracking-[0.16em] uppercase">
                <span className={o.featured ? "text-saffron" : "text-violet"}>{o.code}</span>
                {o.featured && (
                  <span className="clip-corner-sm bg-saffron px-2 py-1 text-plum">Pilot focus</span>
                )}
              </div>
              <h3
                className={cn(
                  "font-display mt-6 text-[1.6rem]",
                  o.featured ? "text-ivory" : "text-deepviolet",
                )}
              >
                {o.title}
              </h3>
              <p className={cn("mt-2 text-[14px]", o.featured ? "text-ivory/70" : "text-muted")}>
                {o.lede}
              </p>
              <ul className="mt-6 flex-1 space-y-3">
                {o.items.map((it) => (
                  <li key={it} className="flex gap-3 text-[14px] leading-relaxed">
                    <span
                      aria-hidden="true"
                      className="mt-2 h-1.5 w-1.5 shrink-0 rotate-45 bg-saffron"
                    />
                    <span className={o.featured ? "text-ivory/85" : "text-ink/80"}>{it}</span>
                  </li>
                ))}
              </ul>
              <div
                className={cn(
                  "mono mt-7 border-t pt-4 text-[10px] tracking-[0.14em] uppercase",
                  o.featured ? "border-ivory/20 text-ivory/55" : "border-line text-muted",
                )}
              >
                {site.pricingVisible ? o.price : "Pricing not published yet"}
              </div>
            </article>
          ))}
        </div>

        <Note className="mt-6">
          Pricing is deliberately not shown. When it exists it will be set per active asset,
          branch and automation — not by counting technicians, which would punish teams for
          onboarding the people who actually use the product.
        </Note>
      </Container>
    </section>
  );
}

/* Section 15 — Mission and principles ------------------------------ */

export function MissionPrinciples() {
  const ref = useReveal<HTMLElement>();
  return (
    <section id="mission" ref={ref} className="relative overflow-hidden bg-plum py-20 text-ivory sm:py-28">
      <Container className="relative">
        <div className="grid gap-12 lg:grid-cols-[1.15fr_0.85fr] lg:items-center">
          <div className="reveal">
            <Eyebrow tone="dark">Chapter 13 · Why we are building it</Eyebrow>
            <h2 className="font-display t-5 mt-6 max-w-[16ch]">
              Completed work should not become{" "}
              <span className="accent text-saffron">a lost customer.</span>
            </h2>
            <p className="mt-6 max-w-[48ch] leading-relaxed text-ivory/70">
              The service ends. The connection stays. That single idea decides what we build, what
              we refuse to build, and what a stranger is allowed to see when they scan a pass.
            </p>
          </div>
          <div className="reveal relative">
            <div
              aria-hidden="true"
              className="absolute inset-0 m-auto aspect-square w-[80%] rounded-full border border-ivory/20"
            />
            <SealRing className="absolute inset-0 m-auto w-[96%] opacity-50" tone="saffron" />
            <div className="relative mx-auto w-[82%] max-w-[380px] py-10">
              <PassObject tilt={6} stack={2} />
            </div>
          </div>
        </div>

        <div className="mt-16 grid gap-px border-t border-ivory/18 md:grid-cols-2 lg:grid-cols-4">
          {principles.map((p) => (
            <div key={p.n} className="reveal border-b border-ivory/15 py-7 pr-6 lg:border-r lg:pl-6 lg:first:pl-0">
              <span className="mono text-[11px] text-saffron">{p.n}</span>
              <h3 className="font-display mt-4 text-[1.25rem]">{p.title}</h3>
              <p className="mt-2.5 text-[14px] leading-relaxed text-ivory/68">{p.body}</p>
            </div>
          ))}
        </div>
      </Container>
    </section>
  );
}

/* Section 16 — Pre-launch transparency ----------------------------- */

export function PrelaunchTransparency() {
  const ref = useReveal<HTMLElement>();
  return (
    <section id="transparency" ref={ref} className="bg-ivory py-20 sm:py-28">
      <Container>
        <div className="reveal max-w-[24ch]">
          <Eyebrow>Chapter 14 · Where we actually are</Eyebrow>
          <h2 className="font-display t-4 mt-5 text-deepviolet">
            We do not have reviews yet.{" "}
            <span className="accent text-violet">The pilot has not started.</span>
          </h2>
        </div>

        <p className="reveal mt-7 max-w-[62ch] text-[16px] leading-[1.7] text-ink/80 sm:text-[17px]">
          ARANCH PASS is currently a product and system concept being prepared for field
          validation. The pass and box shown here are approved design directions. Material tests,
          technician timing, provider adoption and repeat-service results still need to be proven.
        </p>

        <div className="mt-12 grid gap-5 lg:grid-cols-2">
          <div className="reveal clip-corner bg-paper hairline p-6 sm:p-8">
            <h3 className="mono text-[11px] tracking-[0.2em] text-violet uppercase">What exists</h3>
            <ul className="mt-5">
              {transparency.exists.map((t) => (
                <li key={t} className="flex items-start gap-3 border-t border-line py-3.5 text-[15px]">
                  <span aria-hidden="true" className="mt-0.5 text-saffron">
                    ✓
                  </span>
                  <span className="text-ink/85">{t}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="reveal clip-corner bg-paper hairline p-6 sm:p-8">
            <h3 className="mono text-[11px] tracking-[0.2em] text-violet uppercase">
              What remains
            </h3>
            <ul className="mt-5">
              {transparency.remains.map((t) => (
                <li key={t} className="flex items-start gap-3 border-t border-line py-3.5 text-[15px]">
                  <span
                    aria-hidden="true"
                    className="mt-1 grid h-4 w-4 shrink-0 place-items-center rounded-full border border-line text-[9px] text-muted"
                  >
                    ○
                  </span>
                  <span className="text-ink/75">{t}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="reveal mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          <SceneShot
            src={scenes.paperStock.src}
            alt={scenes.paperStock.alt}
            ratio="aspect-square"
            caption="Card stock under evaluation"
            meta="Real"
          />
          <PlannedShot
            path={photographyBrief[0].path}
            ratio="aspect-square"
            brief={photographyBrief[0].note}
          />
          <div className="clip-corner bg-deepviolet p-6 text-ivory sm:p-8">
            <h3 className="font-display t-2">Want to be in the first group?</h3>
            <p className="mt-3 text-[14px] leading-relaxed text-ivory/70">
              Pilot providers get early access, direct input on the workflow and honest updates —
              including the parts that do not work.
            </p>
            <Button href="#pilot" className="mt-6">
              Apply for the first pilot
            </Button>
          </div>
        </div>
      </Container>
    </section>
  );
}
