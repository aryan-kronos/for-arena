import { useEffect, useRef } from "react";
import { PassBackArtwork, PassFrontArtwork } from "@/components/PassArtwork";
import { usePrefersReducedMotion } from "@/hooks/usePrefersReducedMotion";

type Props = {
  className?: string;
  /** thickness of the pass edge in px */
  depth?: number;
};

const REST_Y = -14;
const REST_X = 6;
const MAX_Y = 62;

/**
 * Interactive 3D ARANCH PASS.
 * - autoplay oscillation (never edge-on)
 * - cursor-follow tilt on desktop
 * - pointer/touch drag, eased return to rest, autoplay resumes
 * - reduced motion: static angled view
 */
export function InteractivePass({ className = "", depth = 10 }: Props) {
  const stageRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const reduced = usePrefersReducedMotion();

  useEffect(() => {
    const card = cardRef.current;
    const stage = stageRef.current;
    if (!card || !stage) return;

    if (reduced) {
      card.style.transform = `rotateX(${REST_X}deg) rotateY(${REST_Y}deg)`;
      return;
    }

    let raf = 0;
    let t = 0;
    let rotY = REST_Y;
    let rotX = REST_X;
    let targetY = REST_Y;
    let targetX = REST_X;
    let dragging = false;
    let released = 0; // timestamp of release
    let hovering = false;
    let dragStartX = 0;
    let dragStartY = 0;
    let dragBaseY = 0;
    let dragBaseX = 0;
    let pointerYOffset = 0;
    let pointerXOffset = 0;

    const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));

    const tick = () => {
      t += 0.016;
      if (!dragging) {
        const settling = performance.now() - released < 1400;
        if (settling || hovering) {
          targetY = REST_Y + pointerYOffset;
          targetX = REST_X + pointerXOffset;
        } else {
          // gentle automatic oscillation around rest
          targetY = REST_Y + Math.sin(t * 0.55) * 16 + pointerYOffset;
          targetX = REST_X + Math.sin(t * 0.38) * 3 + pointerXOffset;
        }
        const ease = settling ? 0.055 : 0.09;
        rotY += (targetY - rotY) * ease;
        rotX += (targetX - rotX) * ease;
      }
      card.style.transform = `rotateX(${rotX.toFixed(2)}deg) rotateY(${rotY.toFixed(2)}deg)`;
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);

    const onPointerDown = (e: PointerEvent) => {
      dragging = true;
      card.classList.add("is-dragging");
      dragStartX = e.clientX;
      dragStartY = e.clientY;
      dragBaseY = rotY;
      dragBaseX = rotX;
      card.setPointerCapture?.(e.pointerId);
    };
    const onPointerMove = (e: PointerEvent) => {
      if (dragging) {
        rotY = clamp(dragBaseY + (e.clientX - dragStartX) * 0.45, -170, 170);
        rotX = clamp(dragBaseX - (e.clientY - dragStartY) * 0.22, -34, 34);
        card.style.transform = `rotateX(${rotX.toFixed(2)}deg) rotateY(${rotY.toFixed(2)}deg)`;
        e.preventDefault();
      } else if (e.pointerType === "mouse" && hovering) {
        const r = stage.getBoundingClientRect();
        const nx = (e.clientX - r.left) / r.width - 0.5;
        const ny = (e.clientY - r.top) / r.height - 0.5;
        pointerYOffset = clamp(nx * 34, -MAX_Y, MAX_Y);
        pointerXOffset = clamp(-ny * 14, -20, 20);
      }
    };
    const endDrag = (e?: PointerEvent) => {
      if (!dragging) return;
      dragging = false;
      released = performance.now();
      pointerYOffset = 0;
      pointerXOffset = 0;
      card.classList.remove("is-dragging");
      if (e) card.releasePointerCapture?.(e.pointerId);
    };
    const onEnter = () => {
      hovering = true;
    };
    const onLeave = () => {
      hovering = false;
      pointerYOffset = 0;
      pointerXOffset = 0;
      released = performance.now();
    };

    card.addEventListener("pointerdown", onPointerDown);
    window.addEventListener("pointermove", onPointerMove, { passive: false });
    window.addEventListener("pointerup", endDrag);
    window.addEventListener("pointercancel", endDrag);
    stage.addEventListener("pointerenter", onEnter);
    stage.addEventListener("pointerleave", onLeave);

    return () => {
      cancelAnimationFrame(raf);
      card.removeEventListener("pointerdown", onPointerDown);
      window.removeEventListener("pointermove", onPointerMove);
      window.removeEventListener("pointerup", endDrag);
      window.removeEventListener("pointercancel", endDrag);
      stage.removeEventListener("pointerenter", onEnter);
      stage.removeEventListener("pointerleave", onLeave);
    };
  }, [reduced]);

  return (
    <div ref={stageRef} className={`pass-stage select-none ${className}`}>
      <div
        ref={cardRef}
        className="pass-3d relative aspect-[39/25] w-full"
        style={{ transform: `rotateX(${REST_X}deg) rotateY(${REST_Y}deg)` }}
        aria-hidden="false"
      >
        {/* edge */}
        <div
          className="notch absolute inset-0 bg-[#c9bfa0]"
          style={{ transform: `translateZ(-${depth}px)` }}
        />
        <div
          className="pass-face notch overflow-hidden bg-[#EFEADA] shadow-[0_30px_60px_-30px_rgba(46,7,89,0.55)]"
          style={{ transform: "translateZ(0.5px)" }}
        >
          <PassFrontArtwork className="h-full w-full" dieCut={false} />
        </div>
        <div
          className="pass-face notch overflow-hidden bg-deepviolet"
          style={{ transform: `translateZ(-${depth}px) rotateY(180deg)` }}
        >
          <PassBackArtwork className="h-full w-full" dieCut={false} />
        </div>
      </div>
    </div>
  );
}
