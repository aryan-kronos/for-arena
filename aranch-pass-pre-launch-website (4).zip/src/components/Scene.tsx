import { PassFrontArtwork } from "@/components/PassArtwork";
import { cn } from "@/utils/cn";

/**
 * SceneShot — a real photograph with the EXACT vector pass composited onto it.
 *
 * Why this approach: the photographs are genuine scenes (an appliance, a pair of
 * hands, paper stock) and contain no invented branding. The product itself is
 * always the same approved vector artwork, so the object a provider will hold
 * looks identical in every section of the site. Nothing is faked as a finished
 * production photograph — each frame is captioned as a composite.
 */

type PassPlacement = {
  /** left position, % of frame width */
  x: number;
  /** top position, % of frame height */
  y: number;
  /** pass width, % of frame width */
  w: number;
  /** in-plane rotation, degrees */
  rotate?: number;
  /** perspective tilt around Y, degrees */
  tiltY?: number;
  /** perspective tilt around X, degrees */
  tiltX?: number;
};

export function SceneShot({
  src,
  alt,
  placement,
  ratio = "aspect-[4/3]",
  caption,
  meta,
  tone = "light",
  className,
  priority = false,
}: {
  src: string;
  alt: string;
  placement?: PassPlacement;
  ratio?: string;
  caption: string;
  meta?: string;
  tone?: "light" | "dark";
  className?: string;
  priority?: boolean;
}) {
  return (
    <figure
      className={cn(
        "clip-corner group relative overflow-hidden",
        ratio,
        tone === "light" ? "bg-ivory hairline" : "bg-plum hairline-dark",
        className,
      )}
    >
      <img
        src={src}
        alt={alt}
        loading={priority ? "eager" : "lazy"}
        decoding="async"
        draggable={false}
        className="absolute inset-0 h-full w-full object-cover transition-transform duration-[900ms] ease-out group-hover:scale-[1.035]"
      />

      <div aria-hidden="true" className="scene-tint absolute inset-0" />

      {placement && (
        <div
          aria-hidden="true"
          className="pointer-events-none absolute"
          style={{
            left: `${placement.x}%`,
            top: `${placement.y}%`,
            width: `${placement.w}%`,
            transform: `translate(-50%, -50%) perspective(900px) rotateX(${placement.tiltX ?? 0}deg) rotateY(${placement.tiltY ?? 0}deg) rotate(${placement.rotate ?? 0}deg)`,
          }}
        >
          <PassFrontArtwork className="scene-pass block h-auto w-full" />
        </div>
      )}

      <figcaption
        className={cn(
          "absolute inset-x-0 bottom-0 flex flex-wrap items-center justify-between gap-x-4 gap-y-1 px-4 py-3 backdrop-blur-[2px]",
          tone === "light"
            ? "border-t border-line bg-paper/92"
            : "border-t border-ivory/15 bg-plum/85",
        )}
      >
        <span
          className={cn(
            "label",
            tone === "light" ? "text-violet" : "text-saffron",
          )}
        >
          {caption}
        </span>
        {meta && (
          <span className={cn("label", tone === "light" ? "text-muted" : "text-ivory/50")}>
            {meta}
          </span>
        )}
      </figcaption>
    </figure>
  );
}

/**
 * PassObject — the approved pass rendered as a standalone designed object,
 * with an optional stack beneath it. Used wherever the product is the subject.
 */
export function PassObject({
  className,
  stack = 0,
  tilt = -2,
}: {
  className?: string;
  stack?: number;
  tilt?: number;
}) {
  return (
    <div className={cn("relative", className)} style={{ transform: `rotate(${tilt}deg)` }}>
      {Array.from({ length: stack }).map((_, i) => {
        const d = stack - i;
        return (
          <div
            key={i}
            aria-hidden="true"
            className="absolute inset-0"
            style={{
              transform: `translate(${d * 3}px, ${d * 5}px) rotate(${d * 0.5}deg)`,
              filter: `brightness(${1 - d * 0.045})`,
              opacity: 1,
            }}
          >
            <PassFrontArtwork className="block h-auto w-full" />
          </div>
        );
      })}
      <div className="relative stack-shadow">
        <PassFrontArtwork className="block h-auto w-full" />
      </div>
    </div>
  );
}
