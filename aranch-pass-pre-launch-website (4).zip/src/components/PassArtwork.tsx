import { useMemo } from "react";

/**
 * ARANCH PASS — exact vector reproduction of the approved physical pass.
 *
 * This is the single source of truth for the product object. The SAME artwork is
 * used in the hero 3D pass, the product chapter, the box stack, every scene
 * composite, the activation grid and the favicon — so the physical thing a
 * provider will hold is identical everywhere on the page.
 *
 * Vector (not a photograph) on purpose: it stays perfectly crisp at any size,
 * the QR/asset code/issue number never drift between sections, and no AI
 * re-rendering can distort the approved mark.
 *
 * The pass intentionally carries NO provider name. Provider identity is only
 * ever rendered on the digital scan page.
 */

const CREAM = "#EFEADA";
const CREAM_HI = "#F7F3E6";
const PURPLE = "#3E1263";
const PURPLE_DEEP = "#2E0759";
const SAFFRON = "#F5A81C";

/* ---------------- deterministic QR matrix ---------------- */

const QR_N = 25;

function useQrMatrix(seed: number) {
  return useMemo(() => {
    let s = seed >>> 0;
    const rnd = () => {
      // xorshift — deterministic, stable across renders
      s ^= s << 13;
      s ^= s >>> 17;
      s ^= s << 5;
      return ((s >>> 0) % 1000) / 1000;
    };
    const g: boolean[][] = Array.from({ length: QR_N }, () =>
      Array.from({ length: QR_N }, () => rnd() > 0.52),
    );

    const blank = (ox: number, oy: number, w: number, h: number) => {
      for (let y = 0; y < h; y++)
        for (let x = 0; x < w; x++) {
          const gy = oy + y;
          const gx = ox + x;
          if (gy >= 0 && gy < QR_N && gx >= 0 && gx < QR_N) g[gy][gx] = false;
        }
    };
    // finder patterns + separators
    blank(0, 0, 8, 8);
    blank(QR_N - 8, 0, 8, 8);
    blank(0, QR_N - 8, 8, 8);
    // alignment pattern zone
    blank(QR_N - 9, QR_N - 9, 5, 5);
    // timing patterns
    for (let i = 8; i < QR_N - 8; i++) {
      g[6][i] = i % 2 === 0;
      g[i][6] = i % 2 === 0;
    }
    return g;
  }, [seed]);
}

function QrMatrix({ x, y, size, seed = 20240117 }: { x: number; y: number; size: number; seed?: number }) {
  const g = useQrMatrix(seed);
  const m = size / QR_N;

  const finder = (cx: number, cy: number) => (
    <g key={`f-${cx}-${cy}`}>
      <rect x={x + cx * m} y={y + cy * m} width={m * 7} height={m * 7} fill={PURPLE_DEEP} />
      <rect x={x + (cx + 1) * m} y={y + (cy + 1) * m} width={m * 5} height={m * 5} fill={CREAM_HI} />
      <rect x={x + (cx + 2) * m} y={y + (cy + 2) * m} width={m * 3} height={m * 3} fill={PURPLE_DEEP} />
    </g>
  );

  const alignment = (cx: number, cy: number) => (
    <g>
      <rect x={x + cx * m} y={y + cy * m} width={m * 5} height={m * 5} fill={PURPLE_DEEP} />
      <rect x={x + (cx + 1) * m} y={y + (cy + 1) * m} width={m * 3} height={m * 3} fill={CREAM_HI} />
      <rect x={x + (cx + 2) * m} y={y + (cy + 2) * m} width={m} height={m} fill={PURPLE_DEEP} />
    </g>
  );

  return (
    <g shapeRendering="crispEdges">
      {g.map((row, gy) =>
        row.map((on, gx) =>
          on ? (
            <rect
              key={`${gx}.${gy}`}
              x={x + gx * m}
              y={y + gy * m}
              width={m}
              height={m}
              fill={PURPLE_DEEP}
            />
          ) : null,
        ),
      )}
      {finder(0, 0)}
      {finder(QR_N - 7, 0)}
      {finder(0, QR_N - 7)}
      {alignment(QR_N - 9, QR_N - 9)}
    </g>
  );
}

/* ---------------- ticket silhouette ---------------- */

const W = 780;
const H = 500;

/** Die-cut outline: rounded corners, large mid-edge notches, small step notches. */
export const TICKET_PATH = [
  "M20 0",
  `H${W - 20}`,
  `A20 20 0 0 1 ${W} 20`,
  "V118",
  `A11 11 0 0 0 ${W} 140`,
  "V214",
  `A38 38 0 0 0 ${W} 286`,
  "V360",
  `A11 11 0 0 0 ${W} 382`,
  `V${H - 20}`,
  `A20 20 0 0 1 ${W - 20} ${H}`,
  "H20",
  `A20 20 0 0 1 0 ${H - 20}`,
  "V382",
  "A11 11 0 0 0 0 360",
  "V286",
  "A38 38 0 0 0 0 214",
  "V140",
  "A11 11 0 0 0 0 118",
  "V20",
  "A20 20 0 0 1 20 0",
  "Z",
].join(" ");

let uidCounter = 0;
const nextUid = () => `ap${(uidCounter += 1)}`;

/* ---------------- circular service seal ---------------- */

/**
 * The stamp exactly as approved: outer ring, dotted ring, inner keyline,
 * arc text "ARANCH PASS SERVICE" over the top, asset code and issue number
 * around the bottom, QR and "SCAN FOR SERVICE" in the centre.
 */
export function ServiceSeal({
  className,
  assetCode = "AP-7K3M9",
  issue = "01/50",
  color = PURPLE,
  ink = PURPLE_DEEP,
  showQr = true,
}: {
  className?: string;
  assetCode?: string;
  issue?: string;
  color?: string;
  ink?: string;
  showQr?: boolean;
}) {
  const uid = useMemo(nextUid, []);
  const R = 200;
  const c = 210;

  return (
    <svg viewBox="0 0 420 420" className={className} aria-hidden="true" focusable="false">
      <defs>
        {/* top arc: left -> right over the top */}
        <path id={`${uid}-top`} d={`M ${c - 168} ${c} A 168 168 0 0 1 ${c + 168} ${c}`} fill="none" />
        {/* bottom-left arc (reads upward along the bottom-left) */}
        <path id={`${uid}-code`} d={`M ${c - 12} ${c + 168} A 168 168 0 0 1 ${c - 168} ${c + 8}`} fill="none" />
        {/* bottom-right arc */}
        <path id={`${uid}-issue`} d={`M ${c + 168} ${c + 8} A 168 168 0 0 1 ${c + 12} ${c + 168}`} fill="none" />
      </defs>

      <circle cx={c} cy={c} r={R} fill="none" stroke={color} strokeWidth="5" />
      <circle cx={c} cy={c} r={R - 12} fill="none" stroke={color} strokeWidth="2" />
      {/* dotted ring */}
      <circle
        cx={c}
        cy={c}
        r={R - 26}
        fill="none"
        stroke={color}
        strokeWidth="7"
        strokeLinecap="round"
        strokeDasharray="0.1 15"
      />
      <circle cx={c} cy={c} r={R - 62} fill="none" stroke={color} strokeWidth="3.5" />

      <g
        fill={color}
        style={{ fontFamily: "var(--font-display)", fontWeight: 700 }}
      >
        <text fontSize="35" letterSpacing="2.2">
          <textPath href={`#${uid}-top`} startOffset="50%" textAnchor="middle">
            ARANCH PASS SERVICE
          </textPath>
        </text>
        <text fontSize="31" letterSpacing="2">
          <textPath href={`#${uid}-code`} startOffset="50%" textAnchor="middle">
            {`— ${assetCode} —`}
          </textPath>
        </text>
        <text fontSize="31" letterSpacing="2">
          <textPath href={`#${uid}-issue`} startOffset="50%" textAnchor="middle">
            {`— ${issue} —`}
          </textPath>
        </text>
      </g>

      {/* side rules separating top and bottom arc text */}
      <g stroke={color} strokeWidth="3" strokeLinecap="round">
        <line x1={c - R + 20} y1={c + 4} x2={c - R + 46} y2={c + 4} />
        <line x1={c + R - 46} y1={c + 4} x2={c + R - 20} y2={c + 4} />
      </g>

      {showQr && <QrMatrix x={c - 74} y={c - 88} size={148} />}
      <text
        x={c}
        y={c + 100}
        textAnchor="middle"
        fill={ink}
        fontSize="24"
        letterSpacing="1.4"
        style={{ fontFamily: "var(--font-body)", fontWeight: 700 }}
      >
        SCAN FOR SERVICE
      </text>
    </svg>
  );
}

/* ---------------- monogram ---------------- */

/** Ornate AP monogram: purple face with a saffron offset shadow. */
function Monogram({ x, y, size }: { x: number; y: number; size: number }) {
  const style = {
    fontFamily: "var(--font-display)",
    fontWeight: 900,
    fontStyle: "italic" as const,
  };
  return (
    <g aria-hidden="true">
      <text x={x + size * 0.052} y={y + size * 0.03} fontSize={size} fill={SAFFRON} style={style}>
        AP
      </text>
      <text x={x} y={y} fontSize={size} fill={PURPLE} style={style}>
        AP
      </text>
    </g>
  );
}

/* ---------------- faces ---------------- */

export function PassFrontArtwork({
  className = "",
  /**
   * When false the artwork fills the whole viewBox and the die-cut silhouette is
   * left to the parent (used by the 3D pass, which clips in CSS so the edge slab
   * and both faces share one outline).
   */
  dieCut = true,
}: {
  className?: string;
  dieCut?: boolean;
}) {
  const uid = useMemo(nextUid, []);
  return (
    <svg
      viewBox={`0 0 ${W} ${H}`}
      className={className}
      role="img"
      aria-label="ARANCH PASS service pass: cream ticket with an ornate purple and saffron A P monogram and a circular purple service seal containing a QR code, the asset code A P dash 7 K 3 M 9 and issue number 01 of 50."
    >
      <defs>
        <clipPath id={`${uid}-clip`}>
          {dieCut ? <path d={TICKET_PATH} /> : <rect width={W} height={H} />}
        </clipPath>
        <filter id={`${uid}-paper`} x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="4" seed="7" result="n" />
          <feColorMatrix in="n" type="saturate" values="0" result="d" />
          <feComponentTransfer in="d" result="soft">
            <feFuncA type="linear" slope="0.07" />
          </feComponentTransfer>
          <feComposite in="soft" in2="SourceGraphic" operator="atop" />
        </filter>
        <linearGradient id={`${uid}-stock`} x1="0" y1="0" x2="0.4" y2="1">
          <stop offset="0%" stopColor={CREAM_HI} />
          <stop offset="55%" stopColor={CREAM} />
          <stop offset="100%" stopColor="#E7E1CE" />
        </linearGradient>
      </defs>

      <g clipPath={`url(#${uid}-clip)`}>
        <rect width={W} height={H} fill={`url(#${uid}-stock)`} />
        <rect width={W} height={H} fill={CREAM} filter={`url(#${uid}-paper)`} opacity="0.55" />

        {/* perforation guides */}
        <g stroke={PURPLE} strokeWidth="2.5" strokeDasharray="9 11" opacity="0.32" strokeLinecap="round">
          <line x1="34" y1="26" x2={W - 34} y2="26" />
          <line x1="34" y1={H - 26} x2={W - 34} y2={H - 26} />
        </g>

        <Monogram x={64} y={352} size={268} />

        <g transform={`translate(${W - 452}, 34)`}>
          <ServiceSeal className="" />
        </g>
      </g>

      {dieCut && <path d={TICKET_PATH} fill="none" stroke="rgba(46,7,89,0.16)" strokeWidth="2" />}
    </svg>
  );
}

export function PassBackArtwork({
  className = "",
  dieCut = true,
}: {
  className?: string;
  dieCut?: boolean;
}) {
  const uid = useMemo(nextUid, []);
  return (
    <svg
      viewBox={`0 0 ${W} ${H}`}
      className={className}
      role="img"
      aria-label="Reverse of the ARANCH PASS: every service stays connected."
    >
      <defs>
        <clipPath id={`${uid}-clipb`}>
          {dieCut ? <path d={TICKET_PATH} /> : <rect width={W} height={H} />}
        </clipPath>
      </defs>
      <g clipPath={`url(#${uid}-clipb)`}>
        <rect width={W} height={H} fill={PURPLE_DEEP} />
        <g stroke="rgba(247,240,216,0.10)" strokeWidth="1.5">
          {Array.from({ length: 16 }).map((_, i) => (
            <line key={i} x1={0} y1={i * 32 + 16} x2={W} y2={i * 32 + 16} />
          ))}
        </g>

        <g stroke={SAFFRON} strokeWidth="2.5" strokeDasharray="8 10" opacity="0.55" strokeLinecap="round">
          <line x1="34" y1="26" x2={W - 34} y2="26" />
          <line x1="34" y1={H - 26} x2={W - 34} y2={H - 26} />
        </g>

        <circle cx={W / 2} cy={H / 2} r="150" fill="none" stroke="rgba(245,168,28,0.85)" strokeWidth="3" />
        <circle
          cx={W / 2}
          cy={H / 2}
          r="132"
          fill="none"
          stroke="rgba(247,240,216,0.35)"
          strokeWidth="6"
          strokeLinecap="round"
          strokeDasharray="0.1 14"
        />

        <g
          textAnchor="middle"
          style={{ fontFamily: "var(--font-display)", fontWeight: 700 }}
        >
          <text x={W / 2} y={H / 2 - 26} fontSize="46" fill="#F7F0D8">
            EVERY SERVICE
          </text>
          <text x={W / 2} y={H / 2 + 30} fontSize="46" fill={SAFFRON} fontStyle="italic">
            STAYS CONNECTED.
          </text>
        </g>

        <g
          fill="rgba(247,240,216,0.6)"
          fontSize="20"
          style={{ fontFamily: "var(--font-mono)" }}
        >
          <text x="46" y={H - 48}>
            ARANCH PASS
          </text>
          <text x={W - 46} y={H - 48} textAnchor="end">
            01/50
          </text>
        </g>
      </g>
      {dieCut && <path d={TICKET_PATH} fill="none" stroke="rgba(0,0,0,0.35)" strokeWidth="2" />}
    </svg>
  );
}
